"""
 Copyright (c) 2023, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: Apache License 2.0
 For full license text, see the LICENSE file in the repo root or https://www.apache.org/licenses/LICENSE-2.0
"""

from langchain.prompts import PromptTemplate

# Politifact_DECOMPOSE_INSTRUCTION = """
# Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified.
# Make sure each broken-down claim does not contain pronouns, but rather specific names or things.
# Content: {question}
# Please output in list format ["claim1", ...].
# Please output now:
# """
# PlanKG_Politifact_Decompose_prompt = PromptTemplate(
#                         input_variables=["question"],
#                         template = Politifact_DECOMPOSE_INSTRUCTION,
#                         )

Politifact_Information_Sufficiency_Assessment_INSTRUCTION = """
Based on the provided web information, analyze whether the information has enough evidence to decide whether the statement is true or false. If you think information is enough, respond "0". If you think you need more information, respond ’1’, and tell me which important details are missing from the information. Separate the missing information with ";".
Please provide your evaluation of the claim based on the following format:
Answer: (0/1)[Description of missing information]
Here are examples:
Claim: JAG charges Nancy Pelosi with treason and seditious conspiracy.
Web Information: JAG charges Nancy Pelosi with treason and seditious conspiracy," reads text in the video, alongside the date Dec. 3 and the URL for a website with a history of publishing fictitious stories.
Answer: (0)[The provided information is sufficient.]

Claim: Emerson Moser, who was Crayola’s top crayon molder for almost 40 years, was colorblind.
Web Information: Emerson Moser, then Crayola's most senior crayon moulder, has retired.
Answer: (1)[How long did Emerson Moser work at Crayola?;Is Emerson Moser colorblind?]

Now is your turn:
Claim: {question}
Web Information: {Information}
Answer:
"""
# claim_llm 需要使用的模板
# Politifact_CLAIM_VERI_INSTRUCTION = """
# You are a helpful assistant for fact-checking task.
# Your task is to continuously delve deeper and flexibly execute various actions to complete the verification of a claim. Please strictly follow the steps below, without any additional output.
# (1) Planning: Provide a general description of the content you need to verify and the questions you have, along with feasible verification route.
# (2) Thought: Based on the planned verification route, what additional action need to be taken to investigate the truthfulness of the claim?
# (3) Action: Execute the corresponding action according to the thought above.
# (4) Observation: Obtain the result of action execution.
# The various available actions are defined as follows:
# (1) Search[query]: Use Web Search to find relevant information on a specified query.
# (2) Lookup[query]: Lookup for more detailed information based on the search results. This action can only be executed after searching.
# (3) Ask[question]: Ask the Q&A assistant to answer the question.
# (4) Retrieve[entity name]: Retrieve corresponding entity information through Wikipedia.
# The search and lookup tools are suitable for retrieving the latest information. The ask tool is suitable for directly obtaining answers to questions. The Retrieve tool is suitable for obtaining information about entities.
# Here is one example:
# {examples}
# You need to decide how to use tools and plan flexibly based on the characteristics of the claim to be verified.
# Now is your Turn:
# Claim: {question}{scratchpad}"""

Politifact_CLAIM_VERI_INSTRUCTION = """
You are a helpful assistant for fact-checking task.
Your task is to continuously delve deeper and flexibly execute various actions to complete the verification of a claim. Please strictly follow the steps below, without any additional output.
(1) Planning: Provide a general description of the content you need to verify and the questions you have, along with feasible verification route.
(2) Thought: Based on the planned verification route, what additional action need to be taken to investigate the truthfulness of the claim?
(3) Action: Execute the corresponding action according to the thought above.
(4) Observation: Obtain the result of action execution.
The various available actions are defined as follows:
(1) Search[query]: Use Web Search to find relevant information on a specified query.
(2) Lookup[query]: Lookup for more detailed information based on the search results. This action can only be executed after searching.
(3) Ask[question]: Ask the Q&A assistant to answer the question.
(4) Retrieve[entity name]: Retrieve corresponding entity information through Wikipedia.
(5) Finish[Result]: Provide your verification result of the claim, True or False.
The search and lookup tools are suitable for retrieving the latest information. The ask tool is suitable for directly obtaining answers to questions. The Retrieve tool is suitable for obtaining information about entities.
Here is one example:
{examples}
A claim may be True or False. You need to make a comprehensive judgment based on the information you observe.
Now is your Turn:
Claim: {question}{scratchpad}"""
PlanKG_Politifact_prompt = PromptTemplate(
                        input_variables=["examples","question", "scratchpad"],
                        template = Politifact_CLAIM_VERI_INSTRUCTION,
                        )

# article_llm 需要使用的模板
Politifact_DECOMPOSE_INSTRUCTION = """
You are a helpful assistant for fact-checking task.
Given a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information and the content of the text.
Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things.
Here is one example:
{example}
Now is your turn:
Text: {question}
Claims (Please output in list format): """
PlanKG_Politifact_Decompose_prompt = PromptTemplate(
                        input_variables=["example", "question"],
                        template = Politifact_DECOMPOSE_INSTRUCTION,
                        )

Politifact_TEXT_VERI_INSTRUCTION = """
You are a helpful assistant for fact-checking task.
Given a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information and the content of the text.
Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things.
Here is one example:
{example}
Now is your turn:
Text: {question}
Claims (Please output in list format): {claims}
Verification information: {veri}
Truthfulness of the text (Only output True or False): """
PlanKG_Politifact_Text_Veri_prompt = PromptTemplate(
                        input_variables=["example", "question", "claims", "veri"],
                        template = Politifact_TEXT_VERI_INSTRUCTION,
                        )

Politifact_TEXT_CONCLUSION_INSTRUCTION = """
You are a helpful assistant for fact-checking task.
Given a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information and the content of the text.
Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things.
Here is one example:
{example}
Now is your turn:
Text: {question}
Claims (Please output in list format): {claims}
Verification information: {veri}
Truthfulness of the text (Only output True or False): {result}
Conclusion (Provide reasons): """
PlanKG_Politifact_Text_Conclusion_prompt = PromptTemplate(
                        input_variables=["example", "question", "claims", "veri", "result"],
                        template = Politifact_TEXT_CONCLUSION_INSTRUCTION,
                        )

Politifact_SHOW_INSTRUCTION = """
You are a helpful assistant for fact-checking task.
Given a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information.
Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things.
Here is one example:
{example}
Now is your turn:
Text: {question}
Claims (Please output in list format): {claims}
Verification information: {veri}
Truthfulness of the text (Only output True or False): {result}
Conclusion (Provide reasons): {conclusion}"""
PlanKG_Politifact_Show_prompt = PromptTemplate(
                        input_variables=["example", "question", "claims", "veri", "result", "conclusion"],
                        template = Politifact_SHOW_INSTRUCTION,
                        )

#llama_llm 需要用到的模板
Politifact_GENERATE_ANALYSIS_INSTRUCTION = """
You are a helpful assistant for search results selecting task.
Given multiple results searched from the web and a claim. You need to choose the search results that are most relevant to the claim and can verify its authenticity. The number of results should be at least three.
Here is one example:
{example}
Now is your turn:
Searched results: {search_articles_str}
Claim: {claim}
The search results that can verify the authenticity of the claim are: """
PlanKG_Politifact_Generate_Analysis_prompt= PromptTemplate(
                        input_variables=["search_articles_str", "claim", "example"],
                        template = Politifact_GENERATE_ANALYSIS_INSTRUCTION,
                        )


# 知乎数据模板

Politifact_ZHIHU_VERI_INSTRUCTION = """
你是一个有用的软文广告检测助手，能够帮助识别和标记潜在的软文广告内容。你的任务是分析给定的文本，并根据以下标准判断是否为软文广告：
1. 推销性质：文本中是否存在过度的商品或服务推荐。
2. 夸大宣传：文本是否使用夸张、极端或误导性的语言，试图使产品或服务看起来比实际更具吸引力或效果。
3. 隐性广告：文本是否隐藏了广告的性质，似乎是个人或中立的内容，但实际上是为了推广某个品牌、产品或服务。
请根据这些标准仔细分析文本，提供一个判断结果，明确指出是否为软文广告。
这是一些例子：
{example}
现在轮到你了：
文本: {question}
是否为软文广告（yes or no）: """
PlanKG_ZHIHU_Veri_prompt = PromptTemplate(
                        input_variables=["example", "question"],
                        template = Politifact_ZHIHU_VERI_INSTRUCTION,
                        )

ZHIHU_SHOW_INSTRUCTION = """
你是一个有用的软文广告检测助手，能够帮助识别和标记潜在的软文广告内容。你的任务是分析给定的文本，并根据以下标准判断是否为软文广告：
1. 推销性质：文本中是否存在过度的商品或服务推荐。
2. 夸大宣传：文本是否使用夸张、极端或误导性的语言，试图使产品或服务看起来比实际更具吸引力或效果。
3. 隐性广告：文本是否隐藏了广告的性质，似乎是个人或中立的内容，但实际上是为了推广某个品牌、产品或服务。
请根据这些标准仔细分析文本，提供一个判断结果，明确指出是否为软文广告。
这是一些例子：
{example}
现在轮到你了：
文本: {question}
是否为软文广告（yes or no）: {veri}"""
PlanKG_ZHIHU_Show_prompt = PromptTemplate(
                        input_variables=["example", "question", "veri"],
                        template = ZHIHU_SHOW_INSTRUCTION,
                        )

Fakesv_CLAIM_VERI_INSTRUCTION = """
你是事实核查任务的得力助手。
您的任务是不断深入研究，灵活执行各种操作，以完成声明的验证。请严格遵循以下步骤，不要有任何额外的输出。
（1） Thought：根据现有信息，思考下一步你需要做什么。
（2） Action：根据上述思路执行相应的动作。
（3） Observation：获取动作执行的结果，从外部信息源获取信息。
“Action”步骤中的各种可用操作定义如下：
（1） Search[query]：使用Web搜索查找指定查询的相关信息。
（2） Lookup[query]：根据搜索结果查找更详细的信息。此操作只能在搜索后执行。
（3） Ask[问题]：让问答助理回答问题。
（4） Retrieve[实体名称]：通过维基百科检索相应的实体信息。
（5） Finish[结果]：提供对claim的验证结果，正确或错误。
以下是几个工具的使用例子：
{examples}
如果你已经能够通过连续迭代确定声明的真实性，请在Action步骤中输出Finish[False]<|eot_id|>或Finish[True]<|eot_id|>。
现在轮到你了（1.不要输出?_等符号，只输出文字 2.Thought步骤的输出要多样化，发挥你的思考能力思考下一步还需要哪些信息来验证声明 3.如果声明没有什么有意义的信息，输出这个claim没有验证的价值<|eot_id |>）：
Claim: {question}{scratchpad}"""
PlanKG_Fakesv_prompt = PromptTemplate(
                        input_variables=["examples","question", "scratchpad"],
                        template = Fakesv_CLAIM_VERI_INSTRUCTION,
                        )

Fakesv_SHOW_INSTRUCTION = """
Text: {question}
Claims (Please output in list format): {claims}
Verification information: {veri}
Truthfulness of the text (Only output True or False): {result}
Conclusion (Provide reasons): {conclusion}"""
PlanKG_Fakesv_Show_prompt = PromptTemplate(
                        input_variables=["example", "question", "claims", "veri", "result", "conclusion"],
                        template = Fakesv_SHOW_INSTRUCTION,
                        )