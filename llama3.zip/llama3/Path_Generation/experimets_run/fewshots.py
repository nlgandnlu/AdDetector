"""
 Copyright (c) 2023, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: Apache License 2.0
 For full license text, see the LICENSE file in the repo root or https://www.apache.org/licenses/LICENSE-2.0
"""

PlanKG_Politifact_EXAMPLE = """Claim: Cheri Beasley backs tax hikes — even on families making under $75,000.
Planning (Provide verification plan): This is a claim about politics. I can first use Retrieve and Ask actions to understand the background knowledge, and then use Search and Lookup actions iteratively to conduct in-depth research.<|eot_id|>
Thought 1: Retrieve for basic information about Cheri Beasley may be useful.<|eot_id|>
Action 1: Retrieve[Cheri Beasley]<|eot_id|>
Observation 1: Cheri Lynn Beasley[1] (born February 14, 1966) is an American attorney and jurist who served as the chief justice of the North Carolina Supreme Court from 2019 to 2020 as well as an associate justice from 2012 to 2019.
Thought 2: Understanding Cheri Beasley's fundamental views on tax policy may be helpful.<|eot_id|>
Action 2: Ask[What is Cheri Beasley's basic view and attitude towards tax policy?]<|eot_id|>
Observation 2: Cheri Beasley, a former Chief Justice of the North Carolina Supreme Court and a political candidate, generally advocates for tax policies that promote equity and support working families.
Thought 3: Then I need to search for basic information about this claim.<|eot_id|>
Action 3: Search[Cheri Beasley backs tax hikes — even on families making under $75,000.]<|eot_id|>
Observation 3: A television ad claims that Cheri Beasley supports tax hikes for families making under $75,000, reflecting ongoing political debates (Source: GOP group exaggerates effect of Inflation Reduction Act | Politifact). Analysis of tax contributions suggests that the wealthiest pay the majority of income taxes, raising questions about the accuracy of the claims against Beasley (Source: Fact check: Does Senate candidate Cheri Beasley support higher taxes ... | Reddit).
Thought 4: It appears that GOP group exaggerates effect of Inflation Reduction Act. What content has been exaggerated?<|eot_id|>
Action 4: Lookup[GOP group exaggerates effect of Inflation Reduction Act]<|eot_id|>
Observation 4: Beasley opposes raising taxes on anyone earning $75,000 or less per year, her campaign said when asked about the ad. Her campaign said the claim had already been debunked, pointing to news articles and fact checks showing that claims about tax hikes in the Inflation Reduction Act have been exaggerated. (Source: https://www.politifact.com/factchecks/2022/oct/31/senate-leadership-fund/gop-group-exaggerates-effect-inflation-reduction-a/)
Thought 5: Beasley opposes tax hikes, not supports as claimed. According to observation 3, the claim appeared in a television ad. How does the ad make that claim, and is the depiction accurate?<|eot_id|>
Action 5: Search[A television ad claims that Cheri Beasley supports tax hikes]<|eot_id|>
Observation 5: A 30-second ad features Cheri Beasley speaking to a crowd, juxtaposed with an empty wallet image, emphasizing the claim that she will increase taxes (Source: Ad says Cheri Beasley supports higher taxes. Is that true? | Charlotte Observer). Multiple outlets report the same claim regarding Beasley's alleged support for tax increases, which is a focal point of her opponents' messaging (Source: Fact Check: Ad claims Beasley wants to raise taxes on people making ... | BPR).
Thought 6: The search result 'is that true?' indicates that the claim of the advertisement may not be accurate. What is wrong about this claim?<|eot_id|>
Action 6: Lookup[A television ad claims Cheri Beasley backs tax hikes, is this claim wrong?]<|eot_id|>
Observation 6: After Congress reached a deal in July to pass the Inflation Reduction Act in an effort to boost the economy, attack ads against Democratic Senate candidates began to circulate on TV and online. The ad claims that Beasley wants to raise taxes on nearly everyone, but information from her campaign website shows that she is against tax hikes on the middle class. (Source: https://www.charlotteobserver.com/news/politics-government/article266902911.html)
Thought 7: Cheri Beasley is against tax hikes on the middle class. The information is sufficient for me to make a judgment.<|eot_id|>
Action 7: Finish[False]<|eot_id|>
Conclusion (Provide reasons based on observations): GOP group exaggerates effect of Inflation Reduction Act (Source: Politifact). The claim comes from an attack ad against Democratic Senate candidates (Source: Charlotte Observer).<|eot_id|>
"""



PlanKG_Politifact_Article_Veri_EXAMPLE = """Text: Hillary Clinton Leaves The Country As Mueller Indictment Is Announced. Anyone else think its weird that Hillary Clinton hopped on a jet and flew to the Ukraine last night?On Friday night, Clinton was seen with her husband Bill hopping aboard an aircraft to Lviv at the Ronald Reagan Washington National Airport. This announcement comes after speculation and rumors that one of the indictments handed down by Robert Muellers grand jury were for her.With recent news breaking that Clinton paid a Russian agency for information on Donald Trump, it is unsurprising that Mueller would target Clinton, nor is it really shocking that she would high-tail it out of the country just in case she is one of the people he is coming after on Monday.The interesting thing about the Ukraine is that the country has no extradition agreement with the United States, meaning that she can not be forced to return if indeed she is slated to be arrested Monday.This seems the likeliest scenario, former FBI agent Andrea Hawley told Fox News Saturday. Its worth noting that Hillary Clinton had no scheduled trips to the Ukraine or any reason to go there.Spokespeople for the Clintons have so far refused comment according to Fox and other news organizations.
Claims (Please output in list format): ["Hillary Clinton Leaves The Country As Mueller Indictment Is Announced.", "Hillary Clinton hopped on a jet and flew to the Ukraine last night, meaning that she can not be forced to return if indeed she is slated to be arrested Monday."]
Verification information: The claim "Hillary Clinton Leaves The Country As Mueller Indictment Is Announced." is False. Hillary Rodham Clinton spent her weekend in Washington, D.C., and New York City, not in Lviv, Ukraine, as was claimed in a story that circulated online over the weekend. The claim "Hillary Clinton hopped on a jet and flew to the Ukraine last night, meaning that she can not be forced to return if indeed she is slated to be arrested Monday." is False. The only people implicated in the charges made public on Monday morning were those associated with Donald Trump's campaign.
Truthfulness of the text (Only output True or False): False
Conclusion (Provide reasons): Hillary Rodham Clinton spent her weekend in Washington D.C. and New York City, rather than in Lviv, Ukraine, as reported in a weekend article circulating online. It stated without providing any evidence that the former presidential candidate left the country amid "speculation and rumors" that she will be prosecuted in the Mueller investigation. The only people implicated in the charges made public on Monday morning were those associated with Donald Trump's campaign.
"""

PlanKG_ZHIHU_Veri_EXAMPLE = """文本: 先上硬菜，传送门：黄大礼：喜欢玩游戏买什么手机？
适合王者、吃鸡的游戏手机推荐（2020年9月）游戏手机几个必备的特点，来判断它是不是适合玩游戏：1、处理器（CPU）手机芯片是一款手机的大脑，是最影响游戏性能的因素。
从鲁大师Q2季度的手机芯片排行榜来看，高通骁龙865在CPU和GPU方面的跑分领先第二名一大截；而天玑1000+和华为的旗舰芯片麒麟9905G相差不大。
为了追求极致的游戏性能，我们选购手机时看这3个CPU型号就够了。
（高通骁龙865plus于7月8号发布，未在图上体现）2、散热手机在玩游戏时，散热好坏不仅影响游戏的流畅度，而且影响玩家的体验和心情。
专业的游戏手机通常内置一个小风扇转动，以带走热量，而且有液态水冷散热，保证热量被持续带走。
3、屏幕刷新率从原理上来看，在手机上看视频、玩游戏实际上就是一个个图片在翻转，屏幕刷新率越高，我们就感觉它越流畅。
现在的智能手机屏幕刷新率通常是60hz，好点的是90hz这样，有些专业的电竞手机达到了144hz的高刷。
4、内存内存分为运行内存（RAM）和手机内存（ROM），游戏手机主要优化的是运行内存，增加游戏时的流畅度。
主流的智能手机RAM通常是8G或者12G，游戏手机有些已经达到16G。
5、手机屏幕电竞手机的手机屏幕在刷新率、屏幕分辨率、屏幕大小方面的参数通常是最佳的，以带来最好的游戏体验。
另外，因为游戏玩家对手机的使用时间较长，游戏手机的屏幕通常还使用了护眼、防蓝光等技术。
6、待机时间游戏手机的待机时间必须要长，现在有些手机配置5000mAh、6000mAh大电池，同时支持快充，不耽误游戏时间。
7、音效游戏玩家对音效的要求很高，尤其是吃鸡这类即时战斗型游戏。
通常搭配双扬声器的游戏手机，是比较受欢迎的。
一、专业的游戏手机推荐：二、品牌的电竞级手机推荐（1）高通骁龙865（2）天玑1000+
这里只做部分节选，关于每个手机的介绍在文章里，欢迎参考。
是否为软文广告（yes or no）: yes
"""
# 文本: 今年除了顶级旗舰的竞争依旧火热，2000元价位我们也看到了很多颇具竞争力的新品。
# 在这个需要妥协很多很多的价位，各家到底拿出来了哪些产品?游戏表现和整体体验又到底如何？
# 是否为软文广告（yes or no）: no

PlanKG_Politifact_Generate_Analysis_EXAMPLE = """Search results: Title: The History of the U.S.-Mexico Border Wall | TIME
Link: https://time.com/6324599/bidens-trump-history-border-wall/
Summary: October 30, 2023 10:00 AM EDT. In a seemingly stark policy reversal, President Biden announced his administration will build 20 miles of new fences along the U.S.-Mexico border. DHS Secretary ...

Title: How many miles of border wall did Donald Trump build?
Link: https://www.politifact.com/factchecks/2023/aug/09/donald-trump/how-many-miles-of-border-wall-did-donald-trump-bui/
Summary: The U.S.-Mexico border stretches for 2,000 miles across four states and a variety of terrain. For decades, there have been three types of border barriers — primary, secondary and tertiary.

Title: Trump's Border Wall: Where Does It Stand? - FactCheck.org
Link: https://www.factcheck.org/2020/12/trumps-border-wall-where-does-it-stand/
Summary: But once Trump was elected, he began to move the goal posts — from 1,000 miles to 900 to 800 to 700 and even less. "And remember this, it's a 2,000 mile border, but you don't need 2,000 ...

Title: Mexico-United States border wall - Wikipedia
Link: https://en.wikipedia.org/wiki/Mexico-United_States_border_wall
Summary: Map of the Mexico-United States border wall in 2017 Border fence near El Paso, Texas Border fence between San Diego's border patrol offices in California, U.S. (left) and Tijuana, Mexico (right). The Mexico-United States border wall (Spanish: muro fronterizo Estados Unidos-México) is a series of vertical barriers along the Mexico-United States border intended to reduce illegal ...

Title: Trump wall: How much has he actually built? - BBC
Link: https://www.bbc.com/news/world-us-canada-46824649
Summary: 1. How much 'new wall' Trump has built is up for debate. Any calculation of the miles of new wall constructed by Mr Trump and his administration depends very much on the definition of the words ...

Claim: Perry said: "Building a wall" on the U.S.-Mexico border "will take literally years."

The search results that can verify the authenticity of the claim are: In a seemingly stark policy reversal, President Biden announced his administration will build 20 miles of new fences along the U.S.-Mexico border (Source: The History of the U.S.-Mexico Border Wall | TIME). The U.S.-Mexico border stretches for 2,000 miles across four states and a variety of terrain. For decades, there have been three types of border barriers — primary, secondary and tertiary (Source: How many miles of border wall did Donald Trump build? | Politifact). How much 'new wall' Trump has built is up for debate. Any calculation of the miles of new wall constructed by Mr Trump and his administration depends very much on the definition of the words (Source: Trump wall: How much has he actually built? | BBC).
"""


# PlanKG_Fakesv_EXAMPLE = """Claim: Cheri Beasley backs tax hikes — even on families making under $75,000.
# Thought 1: There are two key points in this claim that need to be verified. I first need to verify whether Cheri Beasley supports tax increases, and then further validate Cheri Beasley's tax policies for families under $75000.<|eot_id|>
# Action 1: Search[Cheri Beasley backs tax hikes?]<|eot_id|>
# Observation 1: A television ad claims that Cheri Beasley supports tax hikes for families making under $75,000, reflecting ongoing political debates (Source: GOP group exaggerates effect of Inflation Reduction Act | Politifact). Analysis of tax contributions suggests that the wealthiest pay the majority of income taxes, raising questions about the accuracy of the claims against Beasley (Source: Fact check: Does Senate candidate Cheri Beasley support higher taxes ... | Reddit).
# """

PlanKG_Fakesv_EXAMPLE = """Claim: Cheri Beasley支持增税，即使是对收入低于75000美元的家庭也是如此。
Thought: Cheri Beasley是否支持增税？<|eot_id |>
Action: Search[Cheri Beasley支持增税]<|eot_id|>
Thought: Cheri Beasley对于75000美元以下家庭也支持增税吗？<|eot_id |>
Action: Search[Cheri Beasley对于75000美元以下家庭也支持增税]<|eot_id|>
Thought: Cheri Beasley对于75000美元以下家庭的详细税收政策是什么？<|eot_id |>
Action: Lookup[Cheri Beasley对于75000美元以下家庭的详细税收政策]<|eot_id|>
Thought: Cheri Beasley本人对于税收政策的观点是什么？<|eot_id |>
Action: Ask[Cheri Beasley本人对于税收政策的观点是什么？]<|eot_id|>
Thought: Cheri Beasley的基本信息是什么？<|eot_id |>
Action: Retrieve[Cheri Beasley]<|eot_id|>
Thought: 获得的信息足以让我做出判断。<|eot_id|>
Action: Finish[False]<|eot_id|>

Claim: 该事件引起了广泛关注和讨论。
Thought: 这个claim没有验证的价值<|eot_id |>
Action: Finish[Uncertain]<|eot_id|>
"""

# PlanKG_Fakesv_EXAMPLE = """Claim: Cheri Beasley backs tax hikes — even on families making under $75,000.
# Planning (Provide verification plan): This is a claim about politics. I can first use Retrieve and Ask actions to understand the background knowledge, and then use Search and Lookup actions iteratively to conduct in-depth research.<|eot_id|>
# Thought 1: Retrieve for basic information about Cheri Beasley may be useful.<|eot_id|>
# Action 1: Retrieve[Cheri Beasley]<|eot_id|>
# Observation 1: Cheri Lynn Beasley[1] (born February 14, 1966) is an American attorney and jurist who served as the chief justice of the North Carolina Supreme Court from 2019 to 2020 as well as an associate justice from 2012 to 2019.
# Thought 2: Understanding Cheri Beasley's fundamental views on tax policy may be helpful.<|eot_id|>
# Action 2: Ask[What is Cheri Beasley's basic view and attitude towards tax policy?]<|eot_id|>
# Observation 2: Cheri Beasley, a former Chief Justice of the North Carolina Supreme Court and a political candidate, generally advocates for tax policies that promote equity and support working families.
# Thought 3: Then I need to search for basic information about this claim.<|eot_id|>
# Action 3: Search[Cheri Beasley backs tax hikes — even on families making under $75,000.]<|eot_id|>
# Observation 3: A television ad claims that Cheri Beasley supports tax hikes for families making under $75,000, reflecting ongoing political debates (Source: GOP group exaggerates effect of Inflation Reduction Act | Politifact). Analysis of tax contributions suggests that the wealthiest pay the majority of income taxes, raising questions about the accuracy of the claims against Beasley (Source: Fact check: Does Senate candidate Cheri Beasley support higher taxes ... | Reddit).
# Thought 4: It appears that GOP group exaggerates effect of Inflation Reduction Act. What content has been exaggerated?<|eot_id|>
# Action 4: Lookup[GOP group exaggerates effect of Inflation Reduction Act]<|eot_id|>
# Observation 4: Beasley opposes raising taxes on anyone earning $75,000 or less per year, her campaign said when asked about the ad. Her campaign said the claim had already been debunked, pointing to news articles and fact checks showing that claims about tax hikes in the Inflation Reduction Act have been exaggerated. (Source: https://www.politifact.com/factchecks/2022/oct/31/senate-leadership-fund/gop-group-exaggerates-effect-inflation-reduction-a/)
# Thought 5: Beasley opposes tax hikes, not supports as claimed. According to observation 3, the claim appeared in a television ad. How does the ad make that claim, and is the depiction accurate?<|eot_id|>
# Action 5: Search[A television ad claims that Cheri Beasley supports tax hikes]<|eot_id|>
# Observation 5: A 30-second ad features Cheri Beasley speaking to a crowd, juxtaposed with an empty wallet image, emphasizing the claim that she will increase taxes (Source: Ad says Cheri Beasley supports higher taxes. Is that true? | Charlotte Observer). Multiple outlets report the same claim regarding Beasley's alleged support for tax increases, which is a focal point of her opponents' messaging (Source: Fact Check: Ad claims Beasley wants to raise taxes on people making ... | BPR).
# Thought 6: The search result 'is that true?' indicates that the claim of the advertisement may not be accurate. What is wrong about this claim?<|eot_id|>
# Action 6: Lookup[A television ad claims Cheri Beasley backs tax hikes, is this claim wrong?]<|eot_id|>
# Observation 6: After Congress reached a deal in July to pass the Inflation Reduction Act in an effort to boost the economy, attack ads against Democratic Senate candidates began to circulate on TV and online. The ad claims that Beasley wants to raise taxes on nearly everyone, but information from her campaign website shows that she is against tax hikes on the middle class. (Source: https://www.charlotteobserver.com/news/politics-government/article266902911.html)
# Thought 7: Cheri Beasley is against tax hikes on the middle class. The information is sufficient for me to make a judgment.<|eot_id|>
# Action 7: Finish[False]<|eot_id|>
# Conclusion (Provide reasons based on observations): GOP group exaggerates effect of Inflation Reduction Act (Source: Politifact). The claim comes from an attack ad against Democratic Senate candidates (Source: Charlotte Observer).<|eot_id|>
# """