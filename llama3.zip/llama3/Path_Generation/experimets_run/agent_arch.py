"""
 Copyright (c) 2023, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: Apache License 2.0
 For full license text, see the LICENSE file in the repo root or https://www.apache.org/licenses/LICENSE-2.0
"""
import time
import random
import re, string, os
import json 
import time
import tiktoken
from langchain.llms.base import BaseLLM
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from collections import Counter
from langchain.utilities import BingSearchAPIWrapper
import pickle
from qwen_vl_utils import process_vision_info
from experimets_run.pre_prompt import PlanKG_Politifact_prompt, PlanKG_Politifact_Decompose_prompt, PlanKG_Politifact_Text_Veri_prompt, PlanKG_Politifact_Text_Conclusion_prompt, PlanKG_Politifact_Show_prompt, PlanKG_Politifact_Generate_Analysis_prompt, PlanKG_ZHIHU_Veri_prompt, PlanKG_ZHIHU_Show_prompt, PlanKG_Fakesv_prompt, PlanKG_Fakesv_Show_prompt
from experimets_run.fewshots import PlanKG_Politifact_EXAMPLE, PlanKG_Politifact_Article_Veri_EXAMPLE, PlanKG_Politifact_Generate_Analysis_EXAMPLE, PlanKG_ZHIHU_Veri_EXAMPLE, PlanKG_Fakesv_EXAMPLE

from experimets_run.llms import token_enc

from experimets_run.config import BING_SUBSCRIPTION_KEY
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
def parse_action(string):
    pattern = r'^(\w+)\[(.+)\]$' 
    match = re.match(pattern, string)
    
    if match:
        action_type = match.group(1)
        argument = match.group(2)
        return action_type, argument
    else:
        action_type, argument = fuzzy_parse_action(string)
        return action_type, argument
        
def fuzzy_parse_action(text):
    text = text.strip(' ').strip('.')
    pattern = r'^(\w+)\[(.+)\]'
    match = re.match(pattern, text)
    if match:
        action_type = match.group(1)
        argument = match.group(2)
        return action_type, argument
    else:
        return text, ''

def get_first_n_words(text, n):
    # 将文本分割为单词
    words = text.split()
    # 提取前n个单词
    first_n_words = words[:n]
    # 将单词重新拼接成字符串
    result = ' '.join(first_n_words)
    return result

def is_only_newlines_and_spaces(s):
    # Remove all newlines and spaces, and check if the string is empty
    return s.strip() == ""

def format_step(step: str) -> str:
    return step.strip('\n').strip().replace('\n', '')

def truncate_scratchpad(scratchpad: str, n_tokens: int = 1600, tokenizer = token_enc) -> str:
    lines = scratchpad.split('\n')
    observations = filter(lambda x: x.startswith('Observation'), lines)
    observations_by_tokens = sorted(observations, key=lambda x: len(tokenizer.encode(x)))
    while len(token_enc.encode('\n'.join(lines))) > n_tokens:
        largest_observation = observations_by_tokens.pop(-1)
        ind = lines.index(largest_observation)
        lines[ind] = largest_observation.split(':')[0] + ': [truncated wikipedia excerpt]'
    return '\n'.join(lines)

def normalize_answer(s):
    def remove_articles(text):
        return re.sub(r"\b(a|an|the)\b", " ", text)
    
    def white_space_fix(text):
        return " ".join(text.split())
    
    def remove_punc(text):
        exclude = set(string.punctuation)
        return "".join(ch for ch in text if ch not in exclude)
    
    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))

def f1_score(prediction, ground_truth):
    normalized_prediction = normalize_answer(prediction)
    normalized_ground_truth = normalize_answer(ground_truth)

    ZERO_METRIC = (0, 0, 0)

    if normalized_prediction in ['yes', 'no', 'noanswer'] and normalized_prediction != normalized_ground_truth:
        return ZERO_METRIC
    if normalized_ground_truth in ['yes', 'no', 'noanswer'] and normalized_prediction != normalized_ground_truth:
        return ZERO_METRIC
  
    prediction_tokens = normalized_prediction.split()
    ground_truth_tokens = normalized_ground_truth.split()
    common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return ZERO_METRIC
    precision = 1.0 * num_same / len(prediction_tokens)
    recall = 1.0 * num_same / len(ground_truth_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1, precision, recall

def EM(answer, key) -> bool:
    #print(normalize_answer(answer),normalize_answer(key))
    return normalize_answer(answer) == normalize_answer(key)


class BaseAgent:
    def __init__(self,
                 question: str,
                 key: str,
                 video_path: str,
                 llm: BaseLLM,
                 context_len: int = 2000,
                 max_steps: int= 10,
                 ) -> None:
        
        self.question = question
        self.answer = ''
        self.claims = ''
        self.veri = ''
        self.result = ''
        self.conclusion = ''
        self.key = key
        self.max_steps = max_steps
        self.agent_prompt = ""
        self.examples = ""
        self.article_veri_example = ""
        self.context_len = context_len
        self.run_error = False
        self.train_use = True
        self.name = "Base_Agent"
        self.pre_action = ''
        self.search_results_num = 3
        self.claim_llm = llm
        # 保存对claim分析的历史信息(提示内容和成功标志)，不随着重置清空
        self.claim_dic = {"claim_prompt":[],"claim_train_use":[],"claim_answer":[],"lookup_content":{}}
        
        self.enc = token_enc
        self.__reset_agent()

    def run(self, reset = True) -> None:
        if reset:
            self.__reset_agent()
        # 首先进行文章分解，形成一个list
        decompose_results = self.prompt_agent_manual('decompose')
        try:
            claim_list = json.loads(decompose_results)
            claim_list = claim_list[:7]
            self.claims = str(claim_list)
        except:
            self.train_use = False
            # 如果是训练模式直接返回即可，节省时间
            if self.mode=='train':
                return
            # 如果不能成功分解为list，首先进行可能的处理, 使用正则表达式提取句子
            claim_list = re.findall(r'\d+\.\s*"([^"]+)"|\d+\.\s*([^.\n]+)', decompose_results)
            # 合并提取结果
            claim_list = [s[0] or s[1] for s in claim_list]
            # 如果仍然不行那么尝试提取，还不行报运行错误
            if not claim_list:
                claim_list = re.findall(r'"(.*?)"', decompose_results)
            if not claim_list:
                self.run_error = True
                claim_list = []
            claim_list = claim_list[:7]
            self.claims = str(claim_list)
        #针对这个list分别进行验证返回验证结果list,处理成一个字符串self.veri
        for claim in claim_list:
            self.get_claim_veri(claim)
            self.veri += 'The claim \"' + claim + '\" is ' + self.claim_answer + '. ' + self.claim_conclusion + ' '
            # 每次对子claim推理结束后应该重置
            self.__reset_agent()
        # 分别给出最终预测结果和结论
        self.result = self.prompt_agent_manual('veri')
        self.conclusion = self.prompt_agent_manual('conclusion')
        # 输出最终结果
        #print(self._build_agent_prompt_mannul('show'))
        # print("The answer is: ", self.is_correct())

    #获取每个claim的验证结论
    def get_claim_veri(self, claim):
        self.claim_now = claim
        # 在所有自推理步骤开始前在这里应该加一个规划步骤
        self._planning()
        #print(self.is_halted(),self.is_finished(),self.run_error)
        while not self.is_halted() and not self.is_finished() and not self.run_error:
            self.step()
        # 在所有自推理步骤结束后在这里应该加一个对原因的总结步骤
        self._conclude()
        self.claim_dic["claim_prompt"].append(self._build_agent_prompt())
        self.claim_dic["claim_train_use"].append(self.claim_train_use)
        self.claim_dic["claim_answer"].append(self.claim_answer)

        #print('-----------------End------------------\n',self._build_agent_prompt())
    def get_search_result_list(self,query,max,task):
        max_attempt_time = 3
        status = False
        i=0
        while status==False:
            i+=1
            if task=='search':
                self.bingsearch_results, status = self.search_on_server(query, max, 'search')
            elif task=='read':
                self.bingsearch_results, status = self.search_on_server(query, max, 'read')
                break
            if i>3:
                break
        return self.bingsearch_results

    # 使用claim_llm和claim_prompt的时候使用
    def prompt_agent(self) -> str:
        #generation = self.claim_llm('how are you?')[len(self._build_agent_prompt()):]
        try:
            generation = self.claim_llm(self._build_agent_prompt())[len(self._build_agent_prompt()):]
            # print('xxxxxxxxxxxxxxxxxxxxxxxxx',generation)
            # 检查claim_prompt中是否存在无效内容
            self.check_claim_train_use(generation)
        except Exception as e:
            print(e)
            self.claim_train_use = False
            generation = ""
        return format_step(generation)

    #方法决定要用哪个llm和那个agent_prompt_builder
    def prompt_agent_manual(self, task) -> str:
        try:
            if task=='veri':
                generation = self.article_llm(self._build_agent_prompt_mannul(task))
            elif task=='decompose' or task=='conclusion':
                generation = self.article_llm(self._build_agent_prompt_mannul(task))
            elif task=='generate_analysis':
                input = self._build_agent_prompt_mannul(task)
                generation = self.llama_llm(input)[len(input):]
            # 检查article_prompt中是否存在无效内
            self.check_train_use(generation)
        except Exception as e:
            print(e)
            generation = ""
        return format_step(generation)
    
    def check_claim_train_use(self, text):
        # 将claim模型不符合预期的生成判定为运行不符合预期，可以在训练中避免使用

        # 如果生成为无效的空内容，不用来训练
        if is_only_newlines_and_spaces(text):
            self.claim_train_use = False

    def check_train_use(self, text):
        # 将模型不符合预期的生成判定为运行不符合预期，可以在训练中避免使用

        # 如果生成为无效的空内容，不用来训练
        if is_only_newlines_and_spaces(text):
            self.train_use = False
            
    def is_finished(self) -> bool:
        return self.finished
    
    def reward(self) -> float:
        return f1_score(self.answer, self.result)   
    
    def is_correct(self) -> bool:
        raise NotImplementedError
    
    def is_halted(self) -> bool:
        return ((self.step_n > self.max_steps)
                or (len(self.enc.encode(self._build_agent_prompt())) > self.context_len)
                ) and not self.finished

    def __reset_agent(self) -> None:
        self.claim_now=''
        self.claim_answer = 'Uncertain'
        self.claim_conclusion = ''
        self.step_n = 1
        self.finished = False
        self.scratchpad: str = ''
        self.bingsearch_results = ''
        self.retrieve_results = ''
        self.ask_result = ''
        self.claim_train_use = True
        self.search_query = ''
        self.history_argument = []

    def set_qa(self, question: str, key: str) -> None:
        self.question = question
        self.key = key

    def _actionpath(self):
        self.scratchpad += f'\nActionPath {self.step_n}:'
        action_path = self.prompt_agent()
        #print('pppppppppppppppppppppppppppp', action_path)
        self.scratchpad += ' ' + action_path
        #print(self.scratchpad.split('\n')[-1])

    def _planning(self):
        self.scratchpad += f'\nPlanning (Provide verification plan):'
        planning = self.prompt_agent()
        #print('tttttttttttttttttttttttttttttttt', planning)
        self.scratchpad += ' ' + planning
        #print(self.scratchpad.split('\n')[-1])

    def _think(self):
        self.scratchpad += f'\nThought {self.step_n}:'
        thought = self.prompt_agent()
        #print('tttttttttttttttttttttttttttttttt', thought)
        self.scratchpad += ' ' + thought
        #print(self.scratchpad.split('\n')[-1])

    def _action(self):
        self.scratchpad += f'\nAction {self.step_n}:'
        action = self.prompt_agent()
        pattern = re.compile(r'\s+(?=\[)')
        action = pattern.sub('', action)
        self.scratchpad += ' ' + action
        #print('aaaaaaaaaaaaaaaaaaaaaaa', action)
        action_type, argument = parse_action(action)
        #print(self.scratchpad.split('\n')[-1])
        return action_type, argument
    

    def _conclude_result(self):
        self.scratchpad += f'\nConclusion (Provide your result (True/False/Uncertain) with reasons):'
        self.claim_conclusion = self.claim_llm(self.scratchpad)[len(self.scratchpad):]
        #print('tttttttttttttttttttttttttttttttt', conclusion)
        self.scratchpad += ' ' + self.claim_conclusion
        #print(self.scratchpad.split('\n')[-1])

    def _conclude(self):
        self.scratchpad += f'\nConclusion (Provide reasons):'
        self.claim_conclusion = self.prompt_agent()
        #print('tttttttttttttttttttttttttttttttt', conclusion)
        self.scratchpad += ' ' + self.claim_conclusion
        #print(self.scratchpad.split('\n')[-1])

    def search_on_server(self, query, max,task):
        url = 'http://219.245.186.56:5000/service'
        #url = 'http://172.16.40.53:5000/service'
        #url = 'http://127.0.0.1:5000/search'
        
        params = {'query': query,'max_results':max, 'task':task}
        
        response = requests.get(url, params=params)
        
        if response.status_code == 200:
            if task == 'search':
                return response.json(), True  # 假设返回的是 JSON 数据
            elif task == 'read':
                return response.content.decode(), True
            elif task == 'retrieve':
                return response.json(), True  # 假设返回的是 JSON 数据
            elif task == 'ask':
                return response.content.decode(), True
        else:
            return ' ', False

    def get_answer(self, argument):
        result = ''
        try:
            query = argument
            max = 5
            status = False
            i=0
            while status==False:
                i+=1
                self.bingsearch_results, status = self.search_on_server(query, max, 'search')
                if i>3:
                    break
            #print(self.bingsearch_results)
            result = self.prompt_agent_manual('generate_analysis')
            #print(result)
        except:
            self.scratchpad += f'No information found. Please consider using other tools.'
        return result
    
    def Retrieve(self, argument):
        result = ''
        try:
            entity = argument
            max = 5
            status = False
            i=0
            while status==False:
                i+=1
                self.retrieve_results, status = self.search_on_server(entity, max, 'retrieve')
                if i>3:
                    break
            result = get_first_n_words(self.retrieve_results[0]['text'], 64)
        except:
            self.scratchpad += f'No information found. Please consider using other tools.'
        return result

    def Ask(self, argument):
        result = ''
        try:
            question = argument
            max = 5
            status = False
            i=0
            while status==False:
                i+=1
                self.ask_result, status = self.search_on_server(question, max, 'ask')
                if i>3:
                    break
            result = get_first_n_words(self.ask_result, 64)
        except:
            self.scratchpad += f'No information found. Please consider using other tools.'
        return result
    
    def Read(self, argument):
        result = ''
        status = False
        try:
            url = argument
            max = 5
            i=0
            while status==False:
                i+=1
                url_content, status = self.search_on_server(url, max, 'read')
                # if i>3:
                #     break
                # 只搜索一次就退出
                break
            result = url_content
        except:
            pass
        return result, status

    # 分割 content 为 chunks
    def split_text(self, content, chunk_size=100):
        words = content.split()
        return [' '.join(words[i:i + chunk_size]) for i in range(0, len(words), chunk_size)]

    # 计算 query 与各 chunk 的相似度，返回最相关的 chunk
    def find_most_relevant_chunk(self, content_list, query, chunk_size=100):
        # 1. 将 content 分成 chunks
        chunks = []
        for content in content_list:
            chunks.extend(self.split_text(content, chunk_size))
        # 2. 使用 TF-IDF 进行特征提取
        vectorizer = TfidfVectorizer().fit(chunks + [query])
        chunks_tfidf = vectorizer.transform(chunks)
        query_tfidf = vectorizer.transform([query])

        # 3. 计算余弦相似度
        similarities = cosine_similarity(query_tfidf, chunks_tfidf)
        # 4. 找到最相关的 chunk
        most_similar_idx = similarities.argmax()
        return chunks[most_similar_idx], similarities[0][most_similar_idx]
    def search_lookup(self, argument):
        query = argument
        if self.bingsearch_results == '':
            return "You need to search first."
        else:
            try:
                content_list = []
                for res in self.bingsearch_results:
                    url = res['href']
                    content, status = self.Read(url)
                    # 如果有查询到的页面内容，需要在其中匹配最相关的内容
                    if status == True:
                        content_list.append(content)
                        #只查询一次减少时间消耗
                        break
                result, sim_score = self.find_most_relevant_chunk(content_list, query)
                self.claim_dic['lookup_content'][self.search_query]=content_list
                return result
            except Exception as e:
                print(e)
                return "No results found. Please consider using other tools."

    def step(self) -> None:
        # agent forward
        ret = self.forward()
        if ret:
            action_type, argument = ret[0], ret[1]
        else:
            action_type = ret
        
        if action_type == 'Finish':
            self.claim_answer = argument
            #print('answer',self.answer)
            self.finished = True
            self.step_n += 1
            return

        # Observe 如果没有结束，则可能有新的动作需要观察结果，并执行对应动作
        self.scratchpad += f'\nObservation {self.step_n}: '
        start_time = time.time()
        if action_type == 'Search':
            #print(self.history_agent_save_results)
            try:
                if format_step(argument) in self.history_agent_save_results['search'].keys():
                    self.pre_action = "Search_history"
                    self.search_query=format_step(argument)
                    self.scratchpad += self.history_agent_save_results['search'][format_step(argument)]
                    
                else:
                    self.pre_action = "Search"
                    tmp = self.get_answer(format_step(argument))
                    self.search_query=format_step(argument)
                    #print('search',tmp)
                    #tmp = self._bingsearch(format_step(argument))
                    self.scratchpad += format_step(tmp)
            except Exception as e:
                print(e)
                self.scratchpad += f'Could not complete Search. Please consider using other tools.'
            
        elif action_type == 'Lookup':
            if self.pre_action == "Search":
                try:
                    self.scratchpad += format_step(self.search_lookup(argument))
                except Exception as e:
                    print(e)
                    self.scratchpad += f'Could not complete Lookup. Please consider using other tools.'
            elif self.pre_action == "Search_history":
                try:
                    result, sim_score = self.find_most_relevant_chunk(self.history_agent_save_results['lookup'][self.search_query], argument)
                    self.scratchpad += format_step(result)
                except Exception as e:
                    print(e)
                    self.scratchpad += f'Could not complete Lookup. Please consider using other tools.'
            else:
                self.scratchpad += f'You need to Search first before you Lookup.'

        elif action_type == 'Retrieve':
            try:
                if format_step(argument) in self.history_agent_save_results['retrieve'].keys():
                    self.scratchpad += self.history_agent_save_results['retrieve'][format_step(argument)]
                else:
                    tmp = self.Retrieve(format_step(argument))
                    self.scratchpad += format_step(tmp)
            except Exception as e:
                print(e)
                self.scratchpad += f'Could not complete Retrieve. Please consider using other tools.'
        elif action_type == 'Ask':
            try:
                if format_step(argument) in self.history_agent_save_results['ask'].keys():
                    self.scratchpad += self.history_agent_save_results['ask'][format_step(argument)]
                else:
                    tmp = self.Ask(format_step(argument))
                    self.scratchpad += format_step(tmp)
            except Exception as e:
                print(e)
                self.scratchpad += f'Could not complete Ask. Please consider using other tools.'
        else:
            self.scratchpad += 'Invalid Action. Valid Actions are Lookup, Search, Retrieve, Ask and Finish.'
            # 出现非法操作的数据不用来训练，但是可以继续运行
            self.claim_train_use = False
        end_time = time.time()
        self.obver_execution_time += end_time - start_time
        self.step_n += 1
    
    def _build_agent_prompt(self) -> str:
        raise NotImplementedError
    
    def forward(self):
        raise NotImplementedError
    
class PlanKG_Politifact(BaseAgent):
    def __init__(self,
                 question: str,
                 key: str,
                 id: int,
                 llm_dic,
                 mode: str,
                 history_agent_save_results,
                 context_len: int = 2000
                 ) -> None:
        super().__init__(question, key, '', llm_dic['claim_llm'], context_len)

        self.examples = PlanKG_Politifact_EXAMPLE
        # claim_llm 的提示
        self.agent_prompt = PlanKG_Politifact_prompt
        # article_llm 的提示
        self.article_veri_example = PlanKG_Politifact_Article_Veri_EXAMPLE
        self.decompose_prompt = PlanKG_Politifact_Decompose_prompt
        self.text_veri_prompt = PlanKG_Politifact_Text_Veri_prompt
        self.text_conclusion_prompt = PlanKG_Politifact_Text_Conclusion_prompt
        self.show_prompt = PlanKG_Politifact_Show_prompt
        # llama_llm的提示
        self.generate_analysis_example = PlanKG_Politifact_Generate_Analysis_EXAMPLE
        self.generate_analysis_prompt = PlanKG_Politifact_Generate_Analysis_prompt
        # 其他属性
        self.name = "PlanKG_Politifact"
        self.article_llm = llm_dic['article_llm']
        self.llama_llm = llm_dic['llama_llm']
        self.id =id
        self.mode = mode
        # history_agent_save_results {'search':{},'ask':{},'retrieve':{},'lookup':{},'correct':bool}
        self.history_agent_save_results = history_agent_save_results

    def forward(self):
        self._think()
        action_type, argument = self._action()
        return action_type, argument

    def _build_agent_prompt(self) -> str:
        return self.agent_prompt.format(
                            examples = self.examples,
                            question = self.claim_now,
                            scratchpad = self.scratchpad)
    
    def _build_agent_prompt_mannul(self, task) -> str:
        if task=='decompose':
            return self.decompose_prompt.format(
                            example = self.article_veri_example,
                            question = self.question)
        elif task=='veri':
            return self.text_veri_prompt.format(
                            example = self.article_veri_example,
                            question = self.question,
                            claims = self.claims,
                            veri = self.veri
                            )
        elif task=='conclusion':
            return self.text_conclusion_prompt.format(
                            example = self.article_veri_example,
                            question = self.question,
                            claims = self.claims,
                            veri = self.veri,
                            result = self.result)
        elif task=='show':
            return self.show_prompt.format(
                            example = self.article_veri_example,
                            question = self.question,
                            claims = self.claims,
                            veri = self.veri,
                            result = self.result,
                            conclusion = self.conclusion)
        elif task=='generate_analysis':
            self.search_articles_str = "\n".join([f"Title: {article['title']}\nLink: {article['href']}\nBody: {article['body']}" for article in self.bingsearch_results])
            return self.generate_analysis_prompt.format(
                            example = self.generate_analysis_example,
                            search_articles_str = self.search_articles_str,
                            claim = self.claim_now
                            )
    
    def is_correct(self) -> bool:
        if "False" in self.result:
            return EM(self.key, "fake")
        elif "True" in self.result:
            return EM(self.key, "real")
        else:
            return False
def get_PolitiFact_agent(agent_name):
    return PlanKG_Politifact


class PlanKG_ZHIHU(BaseAgent):
    def __init__(self,
                 question: str,
                 key: str,
                 id: int,
                 llm_dic,
                 mode: str,
                 history_agent_save_results,
                 context_len: int = 2000
                 ) -> None:
        super().__init__(question, key, '', llm_dic['llama_llm'], context_len)

        # claim_llm 的提示
        self.agent_prompt = PlanKG_Politifact_prompt
        # article_llm 的提示
        self.article_veri_example = PlanKG_ZHIHU_Veri_EXAMPLE
        self.decompose_prompt = PlanKG_Politifact_Decompose_prompt
        self.text_veri_prompt = PlanKG_ZHIHU_Veri_prompt
        self.text_conclusion_prompt = PlanKG_Politifact_Text_Conclusion_prompt
        self.show_prompt = PlanKG_ZHIHU_Show_prompt
        # llama_llm的提示
        self.generate_analysis_example = PlanKG_Politifact_Generate_Analysis_EXAMPLE
        self.generate_analysis_prompt = PlanKG_Politifact_Generate_Analysis_prompt
        # 其他属性
        self.name = "PlanKG_ZHIHU"
        self.article_llm = llm_dic['llama_llm']
        self.id =id
        self.mode = mode
        self.history_agent_save_results = history_agent_save_results
    def __reset_agent(self) -> None:
        self.claim_now=''
        self.claim_answer = 'Uncertain'
        self.claim_conclusion = ''
        self.step_n = 1
        self.finished = False
        self.scratchpad: str = ''
        self.bingsearch_results = ''
        self.retrieve_results = ''
        self.ask_result = ''
        self.claim_train_use = True
        self.search_query = ''
        self.history_argument = []
    def run(self, reset = True) -> None:
        if reset:
            self.__reset_agent()
        # 分别给出最终预测结果和结论
        self.result = self.prompt_agent_manual('veri')
        print(self._build_agent_prompt_mannul('show'))
        # print("The answer is: ", self.is_correct())
    def forward(self):
        self._think()
        action_type, argument = self._action()
        return action_type, argument

    def _build_agent_prompt(self) -> str:
        return self.agent_prompt.format(
                            examples = self.examples,
                            question = self.claim_now,
                            scratchpad = self.scratchpad)
    
    def _build_agent_prompt_mannul(self, task) -> str:
        if task=='veri':
            return self.text_veri_prompt.format(
                            example = self.article_veri_example,
                            question = self.question,
                            )
        elif task=='show':
            return self.show_prompt.format(
                            example = self.article_veri_example,
                            question = self.question,
                            veri = self.result)
    
    def is_correct(self) -> bool:
        if "False" in self.result:
            return EM(self.key, "fake")
        elif "True" in self.result:
            return EM(self.key, "real")
        else:
            return False
def get_ZHIHU_agent(agent_name):
    return PlanKG_ZHIHU


class PlanKG_fakett(BaseAgent):
    def __init__(self,
                 question: str,
                 key: str,
                 id: str,
                 llm_dic,
                 article_processor,
                 mode: str,
                 history_agent_save_results,
                 context_len: int = 2000
                 ) -> None:
        super().__init__(question, key, id, llm_dic['claim_llm'], context_len)

        self.article_processor = article_processor
        self.examples = PlanKG_Politifact_EXAMPLE
        # claim_llm 的提示
        self.agent_prompt = PlanKG_Politifact_prompt
        # article_llm 的提示
        self.article_veri_example = PlanKG_Politifact_Article_Veri_EXAMPLE
        self.decompose_prompt = PlanKG_Politifact_Decompose_prompt
        self.text_veri_prompt = PlanKG_Politifact_Text_Veri_prompt
        self.text_conclusion_prompt = PlanKG_Politifact_Text_Conclusion_prompt
        self.show_prompt = PlanKG_Politifact_Show_prompt
        # llama_llm的提示
        self.generate_analysis_example = PlanKG_Politifact_Generate_Analysis_EXAMPLE
        self.generate_analysis_prompt = PlanKG_Politifact_Generate_Analysis_prompt
        # 其他属性
        self.name = "PlanKG_Politifact"
        self.article_llm = llm_dic['article_llm']
        self.llama_llm = llm_dic['llama_llm']
        self.id =id
        self.mode = mode
        # history_agent_save_results {'search':{},'ask':{},'retrieve':{},'lookup':{},'correct':bool}
        self.history_agent_save_results = history_agent_save_results

    def forward(self):
        self._think()
        action_type, argument = self._action()
        return action_type, argument

    def _build_agent_prompt(self) -> str:
        return self.agent_prompt.format(
                            examples = self.examples,
                            question = self.claim_now,
                            scratchpad = self.scratchpad)
    
    #方法决定要用哪个llm和那个agent_prompt_builder
    def prompt_agent_manual(self, task) -> str:
        try:
            if task=='veri' or task=='decompose' or task=='conclusion':
                # 推理
                inputs = self._build_agent_prompt_mannul(task)
                generated_ids = self.article_llm.generate(**inputs, max_new_tokens=256)
                generated_ids_trimmed = [
                    out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
                ]
                output_text = self.article_processor.batch_decode(
                    generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
                )
                return output_text
            elif task=='generate_analysis':
                input = self._build_agent_prompt_mannul(task)
                generation = self.llama_llm(input)[len(input):]
            # 检查article_prompt中是否存在无效内容
            self.check_train_use(generation)
        except Exception as e:
            print(e)
            generation = ""
        return format_step(generation)
    
    def _build_agent_prompt_mannul(self, task) -> str:
        if task=='decompose':
            messages = [
            {"role": "system", "content": "You are a useful fact checking assistant."},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Video Title:"+self.question+'\n' + 'Video：'},
                        {
                            "type": "video",
                            "video": self.id,
                            "max_pixels": 16384,
                            "fps": 1.0,
                        },
                        {"type": "text", "text": "Please extract distinct key claims that are mutually independent. Make sure each broken-down claim does not contain pronouns, but rather specific names or things. Claims (Please output in list format):"},
                    ],
                },
            ]
            # 输入配置
            text = self.article_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            image_inputs, video_inputs, video_kwargs = process_vision_info(messages, return_video_kwargs=True)
            inputs = self.article_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
                **video_kwargs,
            )
            inputs = inputs.to(self.article_llm.device)
            return inputs
        elif task=='veri':
            messages = [
            {"role": "system", "content": "You are a useful fact checking assistant."},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "Video Title:"+self.question+'\n' + 'Video：'},
                        {
                            "type": "video",
                            "video": self.id,
                            "max_pixels": 16384,
                            "fps": 1.0,
                        },
                        {"type": "text", "text": "Please extract distinct key claims that are mutually independent. Make sure each broken-down claim does not contain pronouns, but rather specific names or things. Claims (Please output in list format):"},
                    ],
                },
                {
                    "role": "assistant",
                    "content": self.claims,
                },
                {
                    "role": "user",
                    "content": "The verification information returned by the external verification tool is as follows:"+self.veri+"\n"+"Based on the content itself and the above information, give a conclusion. Truthfulness of the text (Only output True or False):",
                },
            ]
            # 输入配置
            text = self.article_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            image_inputs, video_inputs, video_kwargs = process_vision_info(messages, return_video_kwargs=True)
            inputs = self.article_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
                **video_kwargs,
            )
            inputs = inputs.to(self.article_llm.device)
            return inputs
        elif task=='conclusion':
            pass
        elif task=='show':
            return self.show_prompt.format(
                            question = self.question,
                            claims = self.claims,
                            veri = self.veri,
                            result = self.result)
        elif task=='generate_analysis':
            self.search_articles_str = "\n".join([f"Title: {article['title']}\nLink: {article['href']}\nBody: {article['body']}" for article in self.bingsearch_results])
            return self.generate_analysis_prompt.format(
                            example = self.generate_analysis_example,
                            search_articles_str = self.search_articles_str,
                            claim = self.claim_now
                            )
    #获取每个claim的验证结论
    def get_claim_veri(self, claim):
        self.claim_now = claim
        # 在所有自推理步骤开始前在这里应该加一个规划步骤
        #self._planning()
        #print(self.is_halted(),self.is_finished(),self.run_error)
        
        while not self.is_halted() and not self.is_finished() and not self.run_error:
            self.step()
        # 在所有自推理步骤结束后在这里应该加一个对原因的总结步骤
        self._conclude()
        self.claim_dic["claim_prompt"].append(self._build_agent_prompt())
        self.claim_dic["claim_train_use"].append(self.claim_train_use)
        self.claim_dic["claim_answer"].append(self.claim_answer)

        #print('-----------------End------------------\n',self._build_agent_prompt())
    def run(self, reset = True) -> None:
        if reset:
            self.__reset_agent()
        # 首先进行文章分解，形成一个list
        decompose_results = self.prompt_agent_manual('decompose')
        try:
            claim_list = json.loads(decompose_results)
            claim_list = claim_list[:3]
            self.claims = str(claim_list)
            print(self.claims)
        except:
            self.train_use = False
            # 如果是训练模式直接返回即可，节省时间
            if self.mode=='train':
                return
            # 如果不能成功分解为list，首先进行可能的处理, 使用正则表达式提取句子
            claim_list = re.findall(r'\d+\.\s*"([^"]+)"|\d+\.\s*([^.\n]+)', decompose_results)
            # 合并提取结果
            claim_list = [s[0] or s[1] for s in claim_list]
            # 如果仍然不行那么尝试提取，还不行报运行错误
            if not claim_list:
                claim_list = re.findall(r'"(.*?)"', decompose_results)
            if not claim_list:
                self.run_error = True
                claim_list = []
            claim_list = claim_list[:3]
            self.claims = str(claim_list)
        #针对这个list分别进行验证返回验证结果list,处理成一个字符串self.veri
        for claim in claim_list:
            self.get_claim_veri(claim)
            self.veri += 'The claim \"' + claim + '\" is ' + self.claim_answer + '. ' + self.claim_conclusion + ' '
            # 每次对子claim推理结束后应该重置
            self.__reset_agent()
        # 分别给出最终预测结果和结论
        self.result = self.prompt_agent_manual('veri')
        self.conclusion = ''

    def is_correct(self) -> bool:
        if "False" in self.result:
            return EM(self.key, "fake")
        elif "True" in self.result:
            return EM(self.key, "real")
        else:
            return False
def get_fakett_agent(agent_name):
    return PlanKG_fakett

class PlanKG_fakesv(BaseAgent):
    def __init__(self,
                 question: str,
                 key: str,
                 id: str,
                 llm_dic,
                 article_processor,
                 mode: str,
                 history_agent_save_results,
                 context_len: int = 2000
                 ) -> None:
        super().__init__(question, key, id, llm_dic['claim_llm'], context_len)

        self.article_processor = article_processor
        self.examples = PlanKG_Fakesv_EXAMPLE
        self.claim_answers = []
        self.claim_conclusions =[]
        #时间计算
        self.decompose_execution_time = 0
        self.result_execution_time = 0
        self.decompose_video_process_time = 0
        self.result_video_process_time = 0
        self.claim_execution_times = []
        # claim_llm 的提示
        self.agent_prompt = PlanKG_Fakesv_prompt
        # article_llm 的提示
        self.article_veri_example = PlanKG_Politifact_Article_Veri_EXAMPLE
        self.decompose_prompt = PlanKG_Politifact_Decompose_prompt
        self.text_veri_prompt = PlanKG_Politifact_Text_Veri_prompt
        self.text_conclusion_prompt = PlanKG_Politifact_Text_Conclusion_prompt
        self.show_prompt = PlanKG_Fakesv_Show_prompt
        # llama_llm的提示
        self.generate_analysis_example = PlanKG_Politifact_Generate_Analysis_EXAMPLE
        self.generate_analysis_prompt = PlanKG_Politifact_Generate_Analysis_prompt
        # 其他属性
        self.name = "PlanKG_Politifact"
        self.article_llm = llm_dic['article_llm']
        self.llama_llm = llm_dic['llama_llm']
        self.id =id
        self.mode = mode
        # history_agent_save_results {'search':{},'ask':{},'retrieve':{},'lookup':{},'correct':bool}
        self.history_agent_save_results = history_agent_save_results

    def forward(self):
        self._think()
        action_type, argument = self._action()
        return action_type, argument

    def _build_agent_prompt(self) -> str:
        return self.agent_prompt.format(
                            examples = self.examples,
                            question = self.claim_now,
                            scratchpad = self.scratchpad)
    
    # 使用claim_llm和claim_prompt的时候使用
    def prompt_agent(self) -> str:
        try:
            generation = self.claim_llm(self._build_agent_prompt())[len(self._build_agent_prompt()):]
            # print('xxxxxxxxxxxxxxxxxxxxxxxxx',generation)
            # 检查claim_prompt中是否存在无效内容
            self.check_claim_train_use(generation)
        except Exception as e:
            print(e)
            self.claim_train_use = False
            generation = ""
        return format_step(generation)

    #方法决定要用哪个llm和那个agent_prompt_builder
    def prompt_agent_manual(self, task) -> str:
        try:
            if task=='veri' or task=='decompose' or task=='conclusion':
                # 推理
                inputs = self._build_agent_prompt_mannul(task)
                #print(inputs)
                generated_ids = self.article_llm.generate(**inputs, max_new_tokens=256)
                #print(generated_ids)
                generated_ids_trimmed = [
                    out_ids[len(in_ids) :] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
                ]
                output_text = self.article_processor.batch_decode(
                    generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
                )
                return output_text[0]
            elif task=='generate_analysis':
                input = self._build_agent_prompt_mannul(task)
                generation = self.llama_llm(input)[len(input):]
            # 检查article_prompt中是否存在无效内容
            self.check_train_use(generation)
        except Exception as e:
            print(e)
            generation = ""
        return format_step(generation)
    
    def _build_agent_prompt_mannul(self, task) -> str:
        if task=='decompose':
            messages = [
            {"role": "system", "content": "你是一个有用的事实核查助手。"},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "视频题目："+self.question+'\n' + '视频：'},
                        {
                            "type": "video",
                            "video": self.id,
                            "max_pixels": 16384,
                            "fps": 1.0,
                        },
                        {"type": "text", "text": "请提取相互独立的不同关键声明。要求：每个声明内容尽可能长，完整且准确，声明数量不多于3个。声明（用\n分隔）："},
                    ],
                },
            ]
            # 输入配置
            text = self.article_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            start_time = time.time()
            image_inputs, video_inputs, video_kwargs = process_vision_info(messages, return_video_kwargs=True)
            end_time = time.time()
            self.decompose_video_process_time = end_time-start_time
            inputs = self.article_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
                **video_kwargs,
            )
            inputs = inputs.to(self.article_llm.device)
            return inputs
        elif task=='veri':
            messages = [
            {"role": "system", "content": "你是一个有用的事实核查助手。"},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "视频题目："+self.question+'\n' + '视频：'},
                        {
                            "type": "video",
                            "video": self.id,
                            "max_pixels": 16384,
                            "fps": 1.0,
                        },
                        {"type": "text", "text": "请提取相互独立的不同关键声明。要求：每个声明内容尽可能长，完整且准确，声明数量不多于3个。声明（用\n分隔）："},
                    ],
                },
                {
                    "role": "assistant",
                    "content": self.claims,
                },
                {
                    "role": "user",
                    "content": "外部验证工具返回的验证信息如下："+self.veri+"\n"+"根据内容本身和上述信息，得出结论。只输出True或者False，不要有额外输出：",
                },
            ]
            # 输入配置
            text = self.article_processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            )
            start_time = time.time()
            image_inputs, video_inputs, video_kwargs = process_vision_info(messages, return_video_kwargs=True)
            end_time = time.time()
            self.result_video_process_time = end_time-start_time
            inputs = self.article_processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt",
                **video_kwargs,
            )
            inputs = inputs.to(self.article_llm.device)
            return inputs
        elif task=='conclusion':
            pass
        elif task=='show':
            #print(self.show_prompt.format(
                            # example = '',
                            # question = self.question,
                            # claims = self.claims,
                            # veri = self.veri,
                            # result = self.result,
                            # conclusion = ''))
            return self.show_prompt.format(
                            example = '',
                            question = self.question,
                            claims = self.claims,
                            veri = self.veri,
                            result = self.result,
                            conclusion = '')
            
        elif task=='generate_analysis':
            self.search_articles_str = "\n".join([f"Title: {article['title']}\nLink: {article['href']}\nBody: {article['body']}" for article in self.bingsearch_results])
            return self.generate_analysis_prompt.format(
                            example = self.generate_analysis_example,
                            search_articles_str = self.search_articles_str,
                            claim = self.claim_now
                            )
    def __reset_agent(self) -> None:
        self.claim_now=''
        self.claim_answer = 'Uncertain'
        self.claim_conclusion = ''
        self.not_use = False
        self.step_n = 1
        self.obver_execution_time = 0
        self.claim_execution_time = 0
        self.finished = False
        self.scratchpad: str = ''
        self.bingsearch_results = ''
        self.retrieve_results = ''
        self.ask_result = ''
        self.claim_train_use = True
        self.search_query = ''
        self.history_argument = []
    
    # no tools
    def get_claim_veri_notools(self, claim):
        self.claim_now = claim
        # 在所有自推理步骤开始前在这里应该加一个规划步骤
        #self._planning()
        #print(self.is_halted(),self.is_finished(),self.run_error)
        start_time = time.time()
        # while not self.is_halted() and not self.is_finished() and not self.run_error and not self.not_use:
        #     self.step()
        # 在所有自推理步骤结束后在这里应该加一个对原因的总结步骤
        self._conclude_result()
        end_time = time.time()
        self.claim_execution_time = end_time-start_time
        self.claim_dic["claim_prompt"].append(self._build_agent_prompt())
        self.claim_dic["claim_train_use"].append(self.claim_train_use)
        self.claim_dic["claim_answer"].append(self.claim_answer)

    #获取每个claim的验证结论
    def get_claim_veri(self, claim):
        self.claim_now = claim
        # 在所有自推理步骤开始前在这里应该加一个规划步骤
        #self._planning()
        #print(self.is_halted(),self.is_finished(),self.run_error)
        start_time = time.time()
        while not self.is_halted() and not self.is_finished() and not self.run_error and not self.not_use:
            self.step()
        # 在所有自推理步骤结束后在这里应该加一个对原因的总结步骤
        self._conclude()
        end_time = time.time()
        self.claim_execution_time = end_time-start_time
        self.claim_dic["claim_prompt"].append(self._build_agent_prompt())
        self.claim_dic["claim_train_use"].append(self.claim_train_use)
        self.claim_dic["claim_answer"].append(self.claim_answer)

        #print('-----------------End------------------\n',self._build_agent_prompt())

    def _think(self):
        self.scratchpad += f'\nThought {self.step_n}:'
        thought = self.prompt_agent()
        #print('tttttttttttttttttttttttttttttttt', thought)
        #由于训练不足导致的问题，直接删除避免噪音
        if 'Cheri Beasley' in thought:
            self.not_use = True
        self.scratchpad += ' ' + thought
        #print(self.scratchpad.split('\n')[-1])
        
    def run(self, reset = True) -> None:
        if reset:
            self.__reset_agent()
        # 首先进行文章分解，形成一个list
        start_time = time.time()
        decompose_results = self.prompt_agent_manual('decompose')
        end_time = time.time()
        self.decompose_execution_time = end_time - start_time
        #print(decompose_results)
        try:
            # .split('\n')
            claim_list = decompose_results.split('\n')
            claim_list = [x for x in claim_list if x !='']
            #claim_list = [decompose_results]
            
            self.claims = str(claim_list)
            claim_list = claim_list[:3]
            #print(self.claims)
        except:
            self.train_use = False
            # 如果是训练模式直接返回即可，节省时间
            if self.mode=='train':
                return
            # 如果不能成功分解为list，首先进行可能的处理, 使用正则表达式提取句子
            claim_list = re.findall(r'\d+\.\s*"([^"]+)"|\d+\.\s*([^.\n]+)', decompose_results)
            # 合并提取结果
            claim_list = [s[0] or s[1] for s in claim_list]
            # 如果仍然不行那么尝试提取，还不行报运行错误
            if not claim_list:
                claim_list = re.findall(r'"(.*?)"', decompose_results)
            if not claim_list:
                self.run_error = True
                claim_list = []
            
            self.claims = str(claim_list)
            claim_list = claim_list[:1]
        #针对这个list分别进行验证返回验证结果list,处理成一个字符串self.veri
        for claim in claim_list:
            #print('hhhhhhh')
            
            self.get_claim_veri(claim)
            #self.scratchpad += 'Claim: '+claim+' 请判断其真实性。'
            #self.get_claim_veri_notools(claim)

            if self.not_use:
                self.claim_answer = 'Uncertain'
                self.claim_conclusion = ''
            self.claim_answers.append(self.claim_answer)
            self.claim_conclusions.append(self.claim_conclusion)
            
            self.veri += 'The claim \"' + claim + '\" is ' + self.claim_answer + '. ' + self.claim_conclusion + ' '
            #self.veri += 'The claim \"' + claim + '\" conclusion is: ' + self.claim_conclusion + ' '
            #print(self.veri)

            self.claim_execution_times.append([self.claim_execution_time, self.obver_execution_time])
            # 每次对子claim推理结束后应该重置
            self.__reset_agent()
        # 分别给出最终预测结果和结论
        start_time = time.time()
        self.result = self.prompt_agent_manual('veri')
        end_time = time.time()
        self.result_execution_time = end_time - start_time
        self.conclusion = ''

    def is_correct(self) -> bool:
        if "False" in self.result:
            return EM(self.key, "false")
        elif "True" in self.result:
            return EM(self.key, "true")
        else:
            return False
def get_fakesv_agent(agent_name):
    return PlanKG_fakesv