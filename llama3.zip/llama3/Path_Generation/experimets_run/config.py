"""
 Copyright (c) 2023, salesforce.com, inc.
 All rights reserved.
 SPDX-License-Identifier: Apache License 2.0
 For full license text, see the LICENSE file in the repo root or https://www.apache.org/licenses/LICENSE-2.0
"""


OPENAI_API_KEY = "empty_key"
BING_SUBSCRIPTION_KEY = "empty_key" 
