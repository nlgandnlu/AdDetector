from tqdm import tqdm
import argparse
import json
import os
import glob
import re
from sklearn.metrics import precision_score, recall_score, f1_score
import random
import csv
prompt_article="You are a helpful assistant for fact-checking task.\nGiven a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information.\nPlease extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things.\nHere is one example:\nText: UPDATE: Hillary Clinton Leaves The Country As Mueller Indictment Is AnnouncedAnyone else think its weird that Hillary Clinton hopped on a jet and flew to the Ukraine last night?On Friday night, Clinton was seen with her husband Bill hopping aboard an aircraft to Lviv at the Ronald Reagan Washington National Airport.This announcement comes after speculation and rumors that one of the indictments handed down by Robert Muellers grand jury were for her.With recent news breaking that Clinton paid a Russian agency for information on Donald Trump, it is unsurprising that Mueller would target Clinton, nor is it really shocking that she would high-tail it out of the country just in case she is one of the people he is coming after on Monday.The interesting thing about the Ukraine is that the country has no extradition agreement with the United States, meaning that she can not be forced to return if indeed she is slated to be arrested Monday.This seems the likeliest scenario, former FBI agent Andrea Hawley told Fox News Saturday. Its worth noting that Hillary Clinton had no scheduled trips to the Ukraine or any reason to go there.Spokespeople for the Clintons have so far refused comment according to Fox and other news organizations.\nClaims (Please output in list format): [\"Hillary Clinton Leaves The Country As Mueller Indictment Is Announced.\", \"Hillary Clinton will be indicted in the Mueller investigation.\"]\nVerification information\uff1aThe claim \"Hillary Clinton Leaves The Country As Mueller Indictment Is Announced.\" is False. Hillary Rodham Clinton spent her weekend in Washington, D.C., and New York City, not in Lviv, Ukraine, as was claimed in a story that circulated online over the weekend. The claim \"Hillary Clinton will be indicted in the Mueller investigation.\" is False. However, the only people implicated in the charges made public on Monday morning were those associated with Donald Trump\u2019s campaign.\nTruthfulness of the text (Only output True or False): False\nConclusion (Provide reasons): The content of the text is False. Hillary Rodham Clinton spent her weekend in Washington D.C. and New York City, rather than in Lviv, Ukraine, as reported in a weekend article circulating online. It stated without providing any evidence that the former presidential candidate left the country amid \"speculation and rumors\" that she will be prosecuted in the Mueller investigation. However, the only person involved in the allegations made public on Monday morning is someone related to Donald Trump's campaign."
prompt_claim="You are a helpful assistant for fact-checking task.\nYour task is to continuously delve deeper and flexibly execute various actions to complete the verification of a claim. Please strictly follow the steps below, without any additional output.\n(1) Planning: Provide a general description of the content you need to verify and the questions you have, along with feasible verification route.\n(2) Thought: Based on the planned verification route, what additional action need to be taken to investigate the truthfulness of the claim?\n(3) Action: Execute the corresponding action according to the thought above.\n(4) Observation: Obtain the result of action execution.\nThe various available actions are defined as follows:\n(1) Search[query]: Use Web Search to find relevant information on a specified query.\n(2) Lookup[query]: Lookup for more detailed information based on the search results. This action can only be executed after searching.\n(3) Ask[question]: Ask the Q&A assistant to answer the question.\n(4) Retrieve[entity name]: Retrieve corresponding entity information through Wikipedia.\n(5) Finish[Result]: Provide your verification result of the claim, True or False.\nThe search and lookup tools are suitable for retrieving the latest information. The ask tool is suitable for directly obtaining answers to questions. The Retrieve tool is suitable for obtaining information about entities.\nHere is one example:\nClaim: Cheri Beasley backs tax hikes \u2014 even on families making under $75,000.\nPlanning (Provide verification plan): This is a claim about politics. I can first use Retrieve and Ask actions to understand the background knowledge, and then use Search and Lookup actions iteratively to conduct in-depth research.<|eot_id|>\nThought 1: Retrieve for basic information about Cheri Beasley may be useful.<|eot_id|>\nAction 1: Retrieve[Cheri Beasley]<|eot_id|>\nObservation 1: Cheri Lynn Beasley[1] (born February 14, 1966) is an American attorney and jurist who served as the chief justice of the North Carolina Supreme Court from 2019 to 2020 as well as an associate justice from 2012 to 2019.\nThought 2: Understanding Cheri Beasley's fundamental views on tax policy may be helpful.<|eot_id|>\nAction 2: Ask[What is Cheri Beasley's basic view and attitude towards tax policy?]<|eot_id|>\nObservation 2: Cheri Beasley, a former Chief Justice of the North Carolina Supreme Court and a political candidate, generally advocates for tax policies that promote equity and support working families.\nThought 3: Then I need to search for basic information about this claim.<|eot_id|>\nAction 3: Search[Cheri Beasley backs tax hikes \u2014 even on families making under $75,000.]<|eot_id|>\nObservation 3: In the television ad commissioned by the Senate Leadership Fund, a narrator says Cheri Beasley \"backs tax hikes \u2014 even on families making under $75,000.\" By Paul Specht October 31, 2022.\nThought 4: The information about \"tax rate increases\" is insufficient. I need to use lookup for more information.<|eot_id|>\nAction 4: Lookup[tax rate increases]<|eot_id|>\nObservation 4: There are no individual tax rate increases for anyone in the bill. Beasley opposes raising taxes on anyone earning $75,000 or less per year, her campaign said when asked about the ad.\nThought 5: The information obtained is sufficient for me to make a judgment. I don't need to perform any further steps.<|eot_id|>\nAction 5: Finish[False]<|eot_id|>\nConclusion (Provide reasons): Cheri Beasley, a former Chief Justice of the North Carolina Supreme Court and a political candidate, generally advocates for tax policies that promote equity and support working families. Beasley opposes raising taxes on anyone earning $75,000 or less per year, but the claim is wrong to suggest it includes a change in tax rates for that income bracket.<|eot_id|>"
prompt_article1="You are a helpful assistant for fact-checking task. Given a segment of text, your task consists of two parts. The first task is to identify several claims that need verification. The second task is to determine the truthfulness of the text based on the verification information. Please extract distinct key claims that no more than 3 and mutually independent from the content provided below. The key claims should be concrete enough containing clear context so that it can be efficiently verified. Make sure each broken-down claim does not contain pronouns, but rather specific names or things. Here is one example: Text: Hillary Clinton Leaves The Country As Mueller Indictment Is Announced. Anyone else think its weird that Hillary Clinton hopped on a jet and flew to the Ukraine last night?On Friday night, Clinton was seen with her husband Bill hopping aboard an aircraft to Lviv at the Ronald Reagan Washington National Airport. This announcement comes after speculation and rumors that one of the indictments handed down by Robert Muellers grand jury were for her.With recent news breaking that Clinton paid a Russian agency for information on Donald Trump, it is unsurprising that Mueller would target Clinton, nor is it really shocking that she would high-tail it out of the country just in case she is one of the people he is coming after on Monday.The interesting thing about the Ukraine is that the country has no extradition agreement with the United States, meaning that she can not be forced to return if indeed she is slated to be arrested Monday.This seems the likeliest scenario, former FBI agent Andrea Hawley told Fox News Saturday. Its worth noting that Hillary Clinton had no scheduled trips to the Ukraine or any reason to go there.Spokespeople for the Clintons have so far refused comment according to Fox and other news organizations. Claims (Please output in list format): [\"Hillary Clinton Leaves The Country As Mueller Indictment Is Announced.", "Hillary Clinton hopped on a jet and flew to the Ukraine last night, meaning that she can not be forced to return if indeed she is slated to be arrested Monday.\"] Verification information：The claim \"Hillary Clinton Leaves The Country As Mueller Indictment Is Announced.\" is False. Hillary Rodham Clinton spent her weekend in Washington, D.C., and New York City, not in Lviv, Ukraine, as was claimed in a story that circulated online over the weekend. The claim \"Hillary Clinton hopped on a jet and flew to the Ukraine last night, meaning that she can not be forced to return if indeed she is slated to be arrested Monday.\" is False. The only people implicated in the charges made public on Monday morning were those associated with Donald Trump’s campaign. Truthfulness of the text (Only output True or False): False Conclusion (Provide reasons): Hillary Rodham Clinton spent her weekend in Washington D.C. and New York City, rather than in Lviv, Ukraine, as reported in a weekend article circulating online. It stated without providing any evidence that the former presidential candidate left the country amid \"speculation and rumors\" that she will be prosecuted in the Mueller investigation. The only people implicated in the charges made public on Monday morning were those associated with Donald Trump’s campaign. "
def load_label_dic(label_file):
    with open(label_file, 'r', encoding='UTF-8') as json_file:
        json_list = json.load(json_file)
    #读取label_dic
    label_dic={}
    for json_str in tqdm(json_list):
        result = json_str
        label = result["label"]
        idx = result["event_id"].replace('.json', '')
        label_dic[idx]=label
    return label_dic

def extract_label(text):
    # 正则表达式模式：匹配最后出现的标签
    pattern = r'\b(true|false|barely-true|half-true|mostly-true|pants-fire)'
    
    # 使用正则表达式搜索文本
    matches = re.findall(pattern, text, re.IGNORECASE)
    # 如果找到匹配项，则返回最后一个标签
    if matches:
        return matches[-1]
    else:
        return None

def load_result_dic(folder_path):
    # 初始化一个空字典来存储文件名和内容
    files_content = {}

    # 使用 glob 模块找到所有 .txt 文件
    txt_files = glob.glob(os.path.join(folder_path, '*.txt'))

    for file_path in txt_files:
        # 获取文件名，不包括路径
        file_name = os.path.basename(file_path)
        # 去掉文件名中的 .txt 后缀
        key = os.path.splitext(file_name)[0]
        
        # 读取文件内容
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # 将文件名和内容添加到字典中
        files_content[key] = extract_label(content)

    return files_content

def test(result_folder, label_file):
    # 定义标签集合
    labels = ['true', 'mostly-true',  'half-true', 'barely-true', 'false', 'pants-fire']
    dic_truth={'true':0, 'false':0, 'barely-true':0, 'half-true':0, 'mostly-true':0, 'pants-fire':0}
    dic_answer={'true':0, 'false':0, 'barely-true':0, 'half-true':0, 'mostly-true':0, 'pants-fire':0}
    wrong=0
    label = load_label_dic(label_file)
    result = load_result_dic(result_folder)
    y_true = [label[k] for k in result if k in label]  # 真实标签
    y_pred = [result[k] for k in result if k in label]  # 预测标签
    for l,r in zip(y_true,y_pred):
        dic_truth[l]+=1
        if r in labels:
            dic_answer[r]+=1
        else:
            wrong+=1
    print('wrong',wrong,'true', dic_answer['true']/dic_truth['true'], 'false', dic_answer['false']/dic_truth['false'],'barely-true', dic_answer['barely-true']/dic_truth['barely-true'],'half-true',dic_answer['half-true']/dic_truth['half-true'], 'mostly-true',dic_answer['mostly-true']/dic_truth['mostly-true'], 'pants-fire',dic_answer['pants-fire']/dic_truth['pants-fire'])
    # 计算宏平均 Precision, Recall 和 F1-score
    precision = precision_score(y_true, y_pred, labels=labels, average='macro')
    recall = recall_score(y_true, y_pred, labels=labels, average='macro')
    f1 = f1_score(y_true, y_pred, labels=labels, average='macro')
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(f"Macro Average Precision: {precision:.4f}")
    print(f"Macro Average Recall: {recall:.4f}")
    print(f"Macro Average F1-score: {f1:.4f}")

    precision = precision_score(y_true, y_pred, labels=labels, average=None)
    recall = recall_score(y_true, y_pred, labels=labels, average=None)
    f1 = f1_score(y_true, y_pred, labels=labels, average=None)
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(precision)
    print(recall)
    print(f1)

def test_jsonl(folder):
    # Initialize lists to store true labels and predicted labels
    labels = ['true', 'mostly-true',  'half-true', 'barely-true', 'false', 'pants-fire']
    y_true = []
    y_pred = []
    dic_truth={'true':0, 'false':0, 'barely-true':0, 'half-true':0, 'mostly-true':0, 'pants-fire':0}
    dic_answer={'true':0, 'false':0, 'barely-true':0, 'half-true':0, 'mostly-true':0, 'pants-fire':0}
    wrong=0
    # Read and parse JSONL file
    with open(folder, 'r') as file:
        for line in file:
            data = json.loads(line.strip())
            y_true.append(data['g_truth'])
            # Assuming 'correct' is a boolean where True means prediction was correct
            y_pred.append(data['answer'])  # Adjust as needed
            dic_truth[data['g_truth']]+=1
            if data['answer'] in labels:
                dic_answer[data['answer']]+=1
            else:
                wrong+=1
    print('wrong',wrong,'true', dic_answer['true']/dic_truth['true'], 'false', dic_answer['false']/dic_truth['false'],'barely-true', dic_answer['barely-true']/dic_truth['barely-true'],'half-true',dic_answer['half-true']/dic_truth['half-true'], 'mostly-true',dic_answer['mostly-true']/dic_truth['mostly-true'], 'pants-fire',dic_answer['pants-fire']/dic_truth['pants-fire'])
    # 计算宏平均 Precision, Recall 和 F1-score
    precision = precision_score(y_true, y_pred, labels=labels, average='macro')
    recall = recall_score(y_true, y_pred, labels=labels, average='macro')
    f1 = f1_score(y_true, y_pred, labels=labels, average='macro')
    
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(f"Macro Average Precision: {precision:.4f}")
    print(f"Macro Average Recall: {recall:.4f}")
    print(f"Macro Average F1-score: {f1:.4f}")

    precision = precision_score(y_true, y_pred, labels=labels, average=None)
    recall = recall_score(y_true, y_pred, labels=labels, average=None)
    f1 = f1_score(y_true, y_pred, labels=labels, average=None)
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(precision)
    print(recall)
    print(f1)
def error_ana_PolitiFact(folder):
    # 进行整体的统计分析
    dic_article = {'True':0,'False':0}
    dic_claim = {'True':0,'False':0,'Uncertain':0}
    dic_claim_trainuse = {True:0,False:0}
    with open(folder, 'r') as file:
        for line in file:
            data = json.loads(line.strip())
            # 输出一些错误案例
            if data['correct']==True and data['error']==False:
                print('***********content***********************', data['id'],'***********content***********************\n')
                #print(data['question'])
                print('answer***********************')
                print(data['prompt'][len(prompt_article):])
                # for d in data['claim_dic']["claim_prompt"]:
                #     print("claim_answer****************************\n")
                #     print(d[len(prompt_claim):])
                # for d in data['claim_dic']["claim_answer"]:
                #     print("claim_answer****************************")
                #     print(d)
            # if data['correct']==False and data['error']==False and data['answer']=='False':
            #     dic_article[data['answer']]+=1
            #     for a,tu,p in zip(data['claim_dic']['claim_answer'],data['claim_dic']['claim_train_use'],data['claim_dic']['claim_prompt']):
            #         dic_claim[a]+=1
            #         dic_claim_trainuse[tu]+=1
            #         if a=='Uncertain':
            #             print('***********************************************')
            #             print(p[len(prompt_claim):])
    #计算比例归一化
    dic_claim_num=dic_claim['True']+dic_claim['False']+dic_claim['Uncertain']
    dic_claim_trainuse_num = dic_claim_trainuse [True]+dic_claim_trainuse [False]
    for k in dic_claim.keys():
        dic_claim[k]=dic_claim[k]/dic_claim_num
    for k in dic_claim_trainuse.keys():
        dic_claim_trainuse[k] = dic_claim_trainuse[k]/dic_claim_trainuse_num
    print('dic_article', dic_article,'dic_claim', dic_claim,'dic_claim_trainuse',dic_claim_trainuse)
def claims_retrieve(prompt: str) -> str:
    end_of_examples_index = prompt.find("Now is your turn:")
    if end_of_examples_index != -1:
        prompt = prompt[end_of_examples_index + len("Now is your turn:") + 1:]
    else:
        prompt = prompt

    prompt_index = prompt.find("Claims (Use '||' as the delimiter): ")
    prompt_index2 = prompt.find("Verification information ")
    
    if prompt_index != -1:
        remaining_content = prompt[prompt_index + len("Claims (Use '||' as the delimiter): "):prompt_index2]
    else:
        remaining_content = ""

    return remaining_content
def test_jsonl_PolitiFact(folder, name):
    # Initialize lists to store true labels and predicted labels
    labels = ['true', 'false']
    y_true = []
    y_pred = []
    dic_truth={'true':0, 'false':0}
    dic_answer={'true':0, 'false':0}
    dic_answer_claim={'True':0, 'False':0, 'Uncertain': 0}
    wrong=0
    num=0
    claim_wrong = 0
    claim_num = 0
    id_list=[]
    false_dic_answer_claim = {'true':0,'false':0,'uncertain':0}
    true_dic_answer_claim = {'true':0,'false':0,'uncertain':0}
    # Read and parse JSONL file
    with open(folder, 'r') as file:
        false_e_num=0
        for line in file:
            data = json.loads(line.strip())
            id = data['id']
            if id in id_list:
                continue
            num+=1
            id_list.append(id)
            if data['g_truth']=='real':
                result = 'true'
            else:
                result = 'false'
            # 通过逻辑门判断，或者什么判断方法试图平衡F值
            # if data['answer'].lower() in labels:
            #     answer = 'true'
            #     false_num=0
            #     true_num=0
            #     for a,tu in zip(data['claim_dic']['claim_answer'],data['claim_dic']['claim_train_use']):
            #         if tu and a=='False':
            #             false_num+=1
            #         elif tu and a=='True':
            #             true_num+=1
            #     if false_num>true_num:
            #         answer='false'
            #     elif false_num==true_num:
            #         #answer=data['answer'].lower()
            #         # if answer=='false':
            #         #     print('****************************************')
            #         #     print(data['prompt'][len(prompt_article):])
            #         answer='true'
            #     else:
            #         # answer=data['answer'].lower()
            #         # if answer=='true' and result == 'false':
            #         #     false_e_num+=1
            #         #     print('****************************************')
            #         #     print(data['prompt'][len(prompt_article):])
            #         answer='true'
                
            #     if answer in labels:
            #         y_pred.append(answer)  # Adjust as needed
            #         dic_answer[answer] += 1
            #         y_true.append(result)
            #         dic_truth[result] += 1
            #     else:
            #         wrong+=1
            #         continue
            # else:
            #     wrong+=1
            #     continue

            # 标准流程    
            if data['answer'].lower() in labels:
                dic_answer[data['answer'].lower()]+=1
                y_pred.append(data['answer'].lower())  # Adjust as needed
                y_true.append(result)
                dic_truth[result]+=1
            else:
                # y_pred.append(data['answer'].lower())  # Adjust as needed
                # y_true.append(result)
                # 列表分解不成功，或者结果是非法结果判定为不成功
                #print(data['prompt'][len(prompt_article):])
                y_pred.append('true')  # Adjust as needed
                y_true.append(result)
                dic_truth['true']+=1
                wrong+=1
            # 统计claim的生成成功率
            for a,tu,p in zip(data['claim_dic']['claim_answer'],data['claim_dic']['claim_train_use'],data['claim_dic']['claim_prompt']):
                # 动作存在非法操作，或者结果是非法结果判定为不成功
                claim_num +=1
                if a != 'True' and a!='False':
                    #print(p)
                    #print(a)
                    a='Uncertain'
                    claim_wrong +=1
                dic_answer_claim[a]+=1
                # 假设都能做对计算
                # y_true.append(result)
                # y_pred.append(result)  # Adjust as needed
                # 对结果全部分类为true和false，进行处理
                if 'false' in data['answer'].lower():
                    false_dic_answer_claim[a.lower()]+=1
                elif 'true' in data['answer'].lower():
                    true_dic_answer_claim[a.lower()]+=1
                # y_true.append(result)
                # dic_truth[result]+=1
            
    print(dic_answer_claim)
    print(dic_truth)
    print(false_dic_answer_claim, true_dic_answer_claim)
    if dic_truth['false']==0:
        dic_truth['false'] = 1
    acc_num=0
    for a,b in zip(y_true,y_pred):
        if a==b:
            acc_num+=1
    print('总数',num,'准确率',acc_num/num,'wrong',wrong,'success_rate',(num-wrong)/num,'claim_num',claim_num, 'claim_wrong', claim_wrong, 'claim_success_rate', (claim_num-claim_wrong)/claim_num,'true', dic_answer['true'], dic_answer['true']/dic_truth['true'], 'false', dic_answer['false'],dic_answer['false']/dic_truth['false'])
    # 计算宏平均 Precision, Recall 和 F1-score
    macro_precision = precision_score(y_true, y_pred, labels=labels, average='macro')
    macro_recall = recall_score(y_true, y_pred, labels=labels, average='macro')
    macro_f1 = f1_score(y_true, y_pred, labels=labels, average='macro')
    # 计算宏平均 Precision, Recall 和 F1-score
    micro_precision = precision_score(y_true, y_pred, labels=labels, average='micro')
    micro_recall = recall_score(y_true, y_pred, labels=labels, average='micro')
    micro_f1 = f1_score(y_true, y_pred, labels=labels, average='micro')
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(f"Macro Average Precision: {macro_precision:.4f}")
    print(f"Macro Average Recall: {macro_recall:.4f}")
    print(f"Macro Average F1-score: {macro_f1:.4f}")
    print(f"Micro Average Precision: {micro_precision:.4f}")
    print(f"Micro Average Recall: {micro_recall:.4f}")
    print(f"Micro Average F1-score: {micro_f1:.4f}")
    precision = precision_score(y_true, y_pred, labels=labels, average=None)
    recall = recall_score(y_true, y_pred, labels=labels, average=None)
    f1 = f1_score(y_true, y_pred, labels=labels, average=None)
    #f1 = 2*precision*recall/(precision+recall)
    # 打印结果
    print(precision)
    print(recall)
    print(f1)
    # 文件路径
    file_path = 'metrics.csv'

    # 字段名（列名）
    fields = ['name','total','wrong','success_rate', 'claim_num', 'claim_wrong', 'claim_success_rate','macro_precision', 'macro_recall', 'macro_f1', 'micro_precision', 'micro_recall', 'micro_f1','true_p','true_r','true_f','false_p','false_r','false_f']
    # 数据行
    row = [name, num, wrong, (num-wrong)/num, claim_num, claim_wrong, (claim_num-claim_wrong)/claim_num, macro_precision, macro_recall,macro_f1, micro_precision, micro_recall, micro_f1, precision[0], recall[0], f1[0], precision[1], recall[1], f1[1]]

    # 判断文件是否存在
    file_exists = os.path.exists(file_path)

    # 打开文件并写入数据
    with open(file_path, mode='a', newline='') as file:
        writer = csv.writer(file)
        
        # 如果文件不存在，先写入字段名（列名）
        if not file_exists:
            writer.writerow(fields)
        
        # 写入数据行
        writer.writerow(row)

    print(f"Metrics saved to {file_path}")
def compare_PolitiFact(file1,file2):
    # 比较两个文件的结果，查询各自犯错的原因的优势
    list1=[]
    list2=[]
    with open(file1, 'r') as file:
        for line in file:
            data = json.loads(line.strip())
            list1.append(data)
    with open(file2, 'r') as file:
        for line in file:
            data = json.loads(line.strip())
            list2.append(data)
    num=0
    for d1 in list1:
        for d2 in list2:
            if d1['id']==d2['id']:
                #if d1['error']==False and d2['error']==True:
                #if d1['g_truth']=='real' and d1['answer']!=d2['answer']:
                if d1['correct']==False and d2['correct']==True:
                    print(d1['id'],d1['answer'],d2['answer'],'***********content***********************\n')
                    print('answer1***********************\n')
                    print(d1['prompt'][len(prompt_article):])
                    print('answer2***********************\n')
                    print(d2['prompt'][len(prompt_article):])
                    num+=1
                    # for d in d1['claim_dic']["claim_prompt"]:
                    #     print("claim_answer****************************\n")
                    #     print(d)
                break
    print(num)
            

def setup_parser():
    parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument("--name", type=str, default="PlanKG_PolitiFact_llama-3-8B_test_0_3_claim")
    parser.add_argument("--complete_folder", type=str, default="/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/trajs/PlanKG_PolitiFact_llama-3-8B_test_0_3_claim.jsonl")
    args = parser.parse_args()
    return args
args = setup_parser()
args.complete_folder = "/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/trajs/" + args.name +'.jsonl'
test_jsonl_PolitiFact(args.complete_folder, args.name)
#error_ana_PolitiFact(args.complete_folder)
#compare_PolitiFact(args.complete_folder, "/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/trajs/PlanKG_PolitiFact_llama-3-8B_test_1_3_article.jsonl")