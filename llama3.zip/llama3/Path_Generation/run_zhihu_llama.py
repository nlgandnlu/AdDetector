import os
import argparse 
import json
import numpy as np
import pandas as pd
import concurrent
import joblib
import torch
import re
import random
random.seed(42)
from experimets_run.utils import summarize_trial_detailed, log_trial
import experimets_run.utils as utils
from experimets_run.agent_arch import get_ZHIHU_agent
from experimets_run.llms import get_llm_backend
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, StoppingCriteriaList, StoppingCriteria
from peft import PeftModel
import warnings
from tqdm import tqdm
import time
warnings.filterwarnings('ignore')


parser = argparse.ArgumentParser(description='Parsing the input of agents, llms and llm context length.')
parser.add_argument("--llm_name", type=str, help="Name of the llm", default="llama-3-8B")
parser.add_argument("--max_context_len", type=int, help="Maximum context length", default=8196)
parser.add_argument("--dataset", type=str, required=True, help="dataset name",default="PolitiFact")
parser.add_argument("--output_path", type=str, required=True, help="output path")
parser.add_argument("--mode", type=str, required=True, help="train,test,val")
parser.add_argument("--inference", type=str, required=True, help="whether need to inference")
parser.add_argument("--version", type=str, required=True, help="modl versione")
parser.add_argument("--peft_mode", type=str, required=True, help="ori/article 0epoch_ori=1_epoch_joint", default='ori')
#设置各种llm的设备号和加载folder
parser.add_argument("--llama_cuda_device", type=int, help="llama_cuda_device", default=0)

args = parser.parse_args()

agent_name = "PlanKG_" + args.dataset
llm_name = args.llm_name
max_context_len = args.max_context_len
mode=args.mode
peft_mode=args.peft_mode
version = args.version
output_path=args.output_path
if args.llama_cuda_device == -1:
    llama_device = torch.device("cpu")
else:
    llama_device = torch.device("cuda",args.llama_cuda_device)
llama_model_Path='/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/models/llama/'

if output_path[-1]!='/':
    output_path+='/'

class KeyWordOne_StoppingCriteria(StoppingCriteria):
    def __init__(self,keyword,tokenizer,device):
        self.keyword = keyword
        self.keyword_tokens = [tokenizer.encode(x,add_special_tokens = False,return_tensors = 'pt').reshape(-1).to(device) for x in keyword]
        self.tokenizer = tokenizer
    def __call__(self,input_ids,scores,**kwards):
        flag = False
        for end_tokens, end in zip(self.keyword_tokens, self.keyword):
            now_str = self.tokenizer.batch_decode(input_ids[0][len(input_ids[0]) - len(end_tokens):], skip_special_tokens=True)[0]
            if len(input_ids[0]) < len(end_tokens):
                continue
            if end in now_str:
                flag = True
                break
            else:
                continue
        return flag
    
def process_agent_run_step(agent):
    agent.run()

def get_tokenizer(path):

    padding_side = "left"
    tokenizer = AutoTokenizer.from_pretrained(path, padding_side=padding_side)
    if tokenizer.pad_token is None or tokenizer.pad_token_id is None:
        print("Missing padding token, setting padding token to eos_token")
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id

    return tokenizer

def get_all_tokenizer():
    return get_tokenizer(llama_model_Path)

def get_model(path):

    model_torch_dtype = torch.float16
    model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=model_torch_dtype)
    return model

def get_all_model():

    # 如果模型保存路径设置为相同，意味着不存在不同的模型，可以在同一个gpu上测试，在平时测试的时候就加载同样的模型即可,这里的写法仍然是之前的device控制的写法，应该修改，以后就是多轮训练了
    ori_model = get_model(llama_model_Path)
    ori_model.to(llama_device)
    article_merge_model = ori_model
    if 'finetune' in version:
        peft_path = 'zhihu/'
        article_p_model = PeftModel.from_pretrained(article_merge_model, model_id=llama_model_Path+'/'+peft_path)
        article_merge_model = article_p_model.merge_and_unload()
        article_merge_model.to(llama_device)
    
    return article_merge_model

def get_llm(model, tokenizer, mode, name):
    # 根据模式设置不同的温度，训练模式应更多样化，验证和测试应保证结果可复现性
    if mode == 'train':
        tem = 0
        do_sample = False
        # 数据中存在#污染，需要去除
        stop_word = ['\n',']','#']
    else:
        tem=0
        do_sample = False
        stop_word = ['\n',']','#']

    if name == 'llama_llm':
        # article_llm， 使用列表对象作为格式化输出，方便总体协调处理
        stopcrieria = KeyWordOne_StoppingCriteria(stop_word,tokenizer=tokenizer,device=llama_device)
        terminators = [
                        tokenizer.eos_token_id,
                        tokenizer.convert_tokens_to_ids("<|eot_id|>")
                        ]
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            device=llama_device,
            #max_length=8192,
            temperature=tem,
            max_new_tokens=5,
            do_sample=do_sample,
            stopping_criteria=StoppingCriteriaList([stopcrieria]),
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=terminators
        )
        llm = get_llm_backend(pipe=pipe).run
        return llm
def read_json(file1):
    list1=[]
    with open(file1, 'r') as file:
        for line in file:
            data = json.loads(line.strip())
            list1.append(data)
    return list1

def prompt_retrieve_claim(prompt: str) -> str:
    end_of_examples_index = prompt.find("Now is your Turn:")
    if end_of_examples_index != -1:
        prompt = prompt[end_of_examples_index + len("Now is your Turn:") + 1:]
    else:
        prompt = prompt

    prompt_index = prompt.find("Planning (Provide verification plan): ")
    
    if prompt_index != -1:
        remaining_content = prompt[prompt_index + len("Planning (Provide verification plan): "):]
    else:
        remaining_content = ""

    # 需要修改，目前定位不准确
    end_index = prompt.find("\n")
    claim = prompt[:end_index]
    return claim, remaining_content

# 需要实现从原始数据中提取的步骤
def extract_history_obser(text):
    # 提取所有的动作和观察结果
    actions = re.findall(r'Action (\d+): (\w+)\[(.*?)\]', text)
    observations = re.findall(r'Observation (\d+): (.*?)(?=\n|<|$)', text)

    # 创建字典
    search = {}
    ask = {}
    retrieve = {}

    # 遍历提取的动作和观察，分配到对应字典
    for action, observation in zip(actions, observations):
        action_number, action_type, action_content = action
        observation_content = observation[1]
        
        if action_type == "Search":
            search[action_content] = observation_content
        elif action_type == "Ask":
            ask[action_content] = observation_content
        elif action_type == "Retrieve":
            retrieve[action_content] = observation_content
    return search, ask, retrieve
def prompt_retrieve_claim(prompt: str) -> str:
    end_of_examples_index = prompt.find("Now is your Turn:")
    if end_of_examples_index != -1:
        prompt = prompt[end_of_examples_index + len("Now is your Turn:") + 1:]
    else:
        prompt = prompt

    prompt_index = prompt.find("Planning (Provide verification plan): ")
    
    if prompt_index != -1:
        remaining_content = prompt[prompt_index + len("Planning (Provide verification plan): "):]
    else:
        remaining_content = ""

    return remaining_content
# 更新到save_dic中
def update_save_results(save_dic, ori_dic):
    # 对该id的每个claim的验证结果都返回四个对应字典进行记录并更新
    for text in ori_dic["claim_dic"]["claim_prompt"]:
        remain_text = prompt_retrieve_claim(text)
        search, ask, retrieve = extract_history_obser(remain_text)
        # 更新save_dic
        save_dic['search'].update(search)
        save_dic['ask'].update(ask)
        save_dic['retrieve'].update(retrieve)
    # 所有claim的lookup结果是统一记录的，所以只需要更新一次
    lookup = ori_dic["claim_dic"]["lookup_content"]
    save_dic['lookup'].update(lookup)
    return save_dic
# 对之前预测正确结果的1/3重新推理
def random_boolean():
    return random.choices([True, False], weights=[1, 2])[0]
def del_some_tasks(task_instructions, history_agent_save_results):
    new_task_instructions = []
    for ques, ans, id in task_instructions:
        if history_agent_save_results[id]['correct']:
            if random_boolean():
                new_task_instructions.append((ques, ans, id))
            else:
                pass
        else:
            new_task_instructions.append((ques, ans, id))
    return new_task_instructions
def find_history_files():
    files = []
    # 每一个模式都应该加入原始第一个输出文件
    if peft_mode!='ori':
        files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{0}_{version}_{'ori'}.jsonl")
    if peft_mode=='sup':
        for e in range(epoch):
            # if e>0:
            #     files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'sup'}.jsonl")
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'article'}.jsonl")
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'claim'}.jsonl")
    elif peft_mode=='article':
        for e in range(epoch):
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'article'}.jsonl")
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'claim'}.jsonl")
            #files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e+1)}_{version}_{'sup'}.jsonl")
    elif peft_mode=='claim':
        files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(0)}_{version}_{'article'}.jsonl")
        for e in range(epoch):
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e)}_{version}_{'claim'}.jsonl")
            #files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e+1)}_{version}_{'sup'}.jsonl")
            files.append(f"{output_path}{agent_name}_{llm_name}_{mode}_{str(e+1)}_{version}_{'article'}.jsonl")
    print('find all history files to refer:', files)
    return files
def run_dataset(data_path):
    task_instructions = []
    history_agent_save_results = {}
    txt_files = [f for f in os.listdir(data_path+'text/') if f.endswith('.txt')]
    for t_f in txt_files:
        if 'no' in t_f:
            label = 'no'
        else:
            label = 'yes'
        with open(data_path+'text/'+t_f, 'r', encoding='utf-8') as file:
            text = file.read()
            task_instructions.append((text,label,data_path+'text/'+t_f))
    agent_save_file = f"{output_path}{agent_name}_{llm_name}_{mode}_{version}_{peft_mode}.jsonl"

    # if os.path.exists(agent_save_file):
    #     sessions = utils.get_all_agent_sessions(agent_save_file)
    #     completed_tasks = utils.get_non_error_tasks(sessions)
    #     task_instructions = [task for task in task_instructions if task not in completed_tasks]
    #     utils.delete_error(agent_save_file)
    #     # known_tasks = utils.get_known_tasks(sessions)
    #     # task_instructions = [task for task in task_instructions if task not in known_tasks]
    #     # utils.delete_unknown(agent_save_file)

    # 把model加载到各自的gpu上
    llama_tokenizer = get_all_tokenizer()
    llama_model = get_all_model()

    # 通过pipeline封装成处理不同任务的专家llm
    llama_llm = get_llm(llama_model, llama_tokenizer, mode, 'llama_llm')
    
    #封装到一个dic中传入agent进行不同的调用
    llm_dic = {'llama_llm':llama_llm}

    # 启用agent协调处理任务
    agent_cls = get_ZHIHU_agent(agent_name)
    agents = []
    i=0
    execution_time = 0
    #task_instructions.reverse()
    for ques, ans, id in tqdm(task_instructions, desc="Running agents"):
        # i+=1
        # if i<60:
        #     continue
        #print(ques, ans, id)
        # if id!=632:
        #     continue
        agent = agent_cls(ques, ans, id, llm_dic, mode, history_agent_save_results, max_context_len)
        agents.append(agent)
        # 开始计时
        start_time = time.time()
        process_agent_run_step(agent)
        end_time = time.time()
        execution_time += (end_time - start_time)
        utils.log_agent(agent, agent_save_file)
        
    print(f'Finished Trial. Total: {len(agents)}', 'print(execution_time)', execution_time)

def prompt_retrieve(prompt: str) -> str:
    end_of_examples_index = prompt.find("Now is your turn:")
    if end_of_examples_index != -1:
        prompt_pre = prompt[:end_of_examples_index + len("Now is your turn:") + 1]
        prompt = prompt[end_of_examples_index + len("Now is your turn:") + 1:]
    else:
        prompt = prompt

    prompt_index = prompt.find("Truthfulness of the text (Only output True or False): ")
    
    prompt_trunk = prompt[:prompt_index+len("Truthfulness of the text (Only output True or False): ")]
    new_prompt = prompt_pre + prompt_trunk
    return new_prompt
def format_step(step: str) -> str:
    return step.strip('\n').strip().replace('\n', '')
def run_fast_label_prediction():
    # 以上一阶段的claim更新模型输出作为基准
    agent_input_file = f"{output_path}{agent_name}_{llm_name}_{mode}_{str(epoch-1)}_{version}_{'article'}.jsonl"
    agent_save_file = f"{output_path}{agent_name}_{llm_name}_{mode}_{str(epoch)}_{version}_{peft_mode}_fast.jsonl"

    # 把model加载到各自的gpu上
    article_tokenizer = get_tokenizer(article_model_Path)
    # 先加载原始模型再逐步迭代加载
    article_merge_model = get_model(llama_model_Path)
    article_merge_model.to(article_device)
    # 因为只涉及到article模型所以不加载claim,和最上面sup的加载方式一致
    for e in range(epoch):
        print('联合加载epoch',e)
        peft_path = 'M'+str(e) +'_article'
        article_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_path)
        article_merge_model = article_p_model.merge_and_unload()
        # peft_sup_path = 'M'+str(e+1)+'_sup'
        # sup_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_sup_path)
        # article_merge_model = sup_p_model.merge_and_unload()
    peft_sup_path = 'M'+str(2)+'_sup'
    sup_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_sup_path)
    article_merge_model = sup_p_model.merge_and_unload()
    article_llm = get_llm(article_merge_model, article_tokenizer, mode, 'article_llm')
    if os.path.exists(agent_save_file):
        os.remove(agent_save_file)
    with open(agent_input_file, 'r') as file:
        for line in tqdm(file):
            data = json.loads(line.strip())
            prompt = data["prompt"]
            error = data["error"]
            new_prompt = prompt_retrieve(prompt)
            generation = article_llm(new_prompt)
            generation = format_step(generation)
            print(generation)
            # 修改原先data的预测结果,如果原来的推理无法进行不进行预测
            if not error:
                data['answer']=generation
            with open(agent_save_file, 'a') as f:
                json.dump(data, f)
                f.write("\n")
            
def main():
    data_path = "/home/baihaitao/transformers/examples/pytorch/sequence-labeling/ZHIHU-16K/" + args.dataset +'/'
    # 正常情况是需要继续推理的，否则就是利用已有的信息进行label更新
    if args.inference == 'true':
        run_dataset(data_path)

if __name__ == '__main__':
    main()