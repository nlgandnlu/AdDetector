#!/bin/sh

# 启用 set -e 以便遇到错误时立即停止执行
set -e

run_inference(){
    dataset_name=$1
    llama_cuda_device=$2
    outname=$3
    python run_zhihu_llama.py --llm_name llama-3-8B --max_context_len 8192 --dataset ${dataset_name} --output_path ../ZHIHU/ --llama_cuda_device ${llama_cuda_device} --version ${outname} --mode test --peft_mode ori --inference true
    echo ${output_dir}
}

cd /home/baihaitao/fake_news/KnowAgent-main/Path_Generation/ &&
# run_inference ZHIHU_test0 4 ZHIHU_test0 &&
# run_inference ZHIHU_test1 4 ZHIHU_test1 &&
# run_inference ZHIHU_test2 4 ZHIHU_test2 &&
# run_inference ZHIHU_test3 4 ZHIHU_test3 &&
# run_inference ZHIHU_test4 4 ZHIHU_test4 &&
# run_inference ZHIHU_test5 4 ZHIHU_test5 &&
# run_inference ZHIHU_test6 4 ZHIHU_test6 &&
# run_inference ZHIHU_test7 4 ZHIHU_test7 &&
# run_inference ZHIHU_test8 4 ZHIHU_test8 &&
# run_inference ZHIHU_test9 4 ZHIHU_test9 &&
# run_inference ZHIHU_test10 4 ZHIHU_test10 &&
# run_inference ZHIHU_test11 4 ZHIHU_test11 &&
# run_inference ZHIHU_test12 4 ZHIHU_test12 &&

# run_inference ZHIHU_test0 4 ZHIHU_test0_finetune_1epoch &&
# run_inference ZHIHU_test1 4 ZHIHU_test1_finetune_1epoch &&
# run_inference ZHIHU_test2 4 ZHIHU_test2_finetune_1epoch &&
# run_inference ZHIHU_test3 4 ZHIHU_test3_finetune_1epoch &&
# run_inference ZHIHU_test4 4 ZHIHU_test4_finetune_1epoch &&
# run_inference ZHIHU_test5 4 ZHIHU_test5_finetune_1epoch &&
# run_inference ZHIHU_test6 4 ZHIHU_test6_finetune_1epoch &&
# run_inference ZHIHU_test7 4 ZHIHU_test7_finetune_1epoch &&
# run_inference ZHIHU_test8 4 ZHIHU_test8_finetune_1epoch &&
# run_inference ZHIHU_test9 4 ZHIHU_test9_finetune_1epoch &&
# run_inference ZHIHU_test10 4 ZHIHU_test10_finetune_1epoch &&
# run_inference ZHIHU_test11 4 ZHIHU_test11_finetune_1epoch &&
# run_inference ZHIHU_test12 4 ZHIHU_test12_finetune_1epoch &

cd /home/baihaitao/fake_news/KnowAgent-main/Self-Learning/ &&
deepspeed --include localhost:3 --master_port 16663 train/train_lora.py \
    --model_name_or_path  models/llama/ \
    --lora_r 4 \
    --lora_alpha 16 \
    --lora_dropout 0.05 \
    --data_path trajs/ZHIHU_data_train.json \
    --output_dir models/llama/zhihu \
    --num_train_epochs 1 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 1 \
    --gradient_accumulation_steps 2 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10000 \
    --save_total_limit 1 \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --fp16 True \
    --model_max_length 8192 \
    --gradient_checkpointing True \
    --q_lora False \
    --resume_from_checkpoint False &&
cd /home/baihaitao/fake_news/KnowAgent-main/Path_Generation/ &&
run_inference ZHIHU_test0 4 ZHIHU_test0_finetune_1epoch_4rank &&
run_inference ZHIHU_test1 4 ZHIHU_test1_finetune_1epoch_4rank &&
run_inference ZHIHU_test2 4 ZHIHU_test2_finetune_1epoch_4rank &&
run_inference ZHIHU_test3 4 ZHIHU_test3_finetune_1epoch_4rank &&
run_inference ZHIHU_test4 4 ZHIHU_test4_finetune_1epoch_4rank &&
run_inference ZHIHU_test5 4 ZHIHU_test5_finetune_1epoch_4rank &&
run_inference ZHIHU_test6 4 ZHIHU_test6_finetune_1epoch_4rank &&
run_inference ZHIHU_test7 4 ZHIHU_test7_finetune_1epoch_4rank &&
run_inference ZHIHU_test8 4 ZHIHU_test8_finetune_1epoch_4rank &&
run_inference ZHIHU_test9 4 ZHIHU_test9_finetune_1epoch_4rank &&
run_inference ZHIHU_test10 4 ZHIHU_test10_finetune_1epoch_4rank &&
run_inference ZHIHU_test11 4 ZHIHU_test11_finetune_1epoch_4rank &&
run_inference ZHIHU_test12 4 ZHIHU_test12_finetune_1epoch_4rank &&

cd /home/baihaitao/fake_news/KnowAgent-main/Self-Learning/ &&
deepspeed --include localhost:3 --master_port 16663 train/train_lora.py \
    --model_name_or_path  models/llama/ \
    --lora_r 4 \
    --lora_alpha 16 \
    --lora_dropout 0.1 \
    --data_path trajs/ZHIHU_data_train.json \
    --output_dir models/llama/zhihu \
    --num_train_epochs 1 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 1 \
    --gradient_accumulation_steps 2 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10000 \
    --save_total_limit 1 \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --fp16 True \
    --model_max_length 8192 \
    --gradient_checkpointing True \
    --q_lora False \
    --resume_from_checkpoint False &&
cd /home/baihaitao/fake_news/KnowAgent-main/Path_Generation/ &&
run_inference ZHIHU_test0 4 ZHIHU_test0_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test1 4 ZHIHU_test1_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test2 4 ZHIHU_test2_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test3 4 ZHIHU_test3_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test4 4 ZHIHU_test4_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test5 4 ZHIHU_test5_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test6 4 ZHIHU_test6_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test7 4 ZHIHU_test7_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test8 4 ZHIHU_test8_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test9 4 ZHIHU_test9_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test10 4 ZHIHU_test10_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test11 4 ZHIHU_test11_finetune_1epoch_4rank_01drop &&
run_inference ZHIHU_test12 4 ZHIHU_test12_finetune_1epoch_4rank_01drop &&

cd /home/baihaitao/fake_news/KnowAgent-main/Self-Learning/ &&
deepspeed --include localhost:3 --master_port 16663 train/train_lora.py \
    --model_name_or_path  models/llama/ \
    --lora_r 4 \
    --lora_alpha 8 \
    --lora_dropout 0.1 \
    --data_path trajs/ZHIHU_data_train.json \
    --output_dir models/llama/zhihu \
    --num_train_epochs 1 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 1 \
    --gradient_accumulation_steps 2 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10000 \
    --save_total_limit 1 \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --fp16 True \
    --model_max_length 8192 \
    --gradient_checkpointing True \
    --q_lora False \
    --resume_from_checkpoint False &&
cd /home/baihaitao/fake_news/KnowAgent-main/Path_Generation/ &&
run_inference ZHIHU_test0 4 ZHIHU_test0_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test1 4 ZHIHU_test1_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test2 4 ZHIHU_test2_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test3 4 ZHIHU_test3_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test4 4 ZHIHU_test4_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test5 4 ZHIHU_test5_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test6 4 ZHIHU_test6_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test7 4 ZHIHU_test7_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test8 4 ZHIHU_test8_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test9 4 ZHIHU_test9_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test10 4 ZHIHU_test10_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test11 4 ZHIHU_test11_finetune_1epoch_4rank_01drop_8alpha &&
run_inference ZHIHU_test12 4 ZHIHU_test12_finetune_1epoch_4rank_01drop_8alpha &