python train/HotpotQA_reformat.py \
    --input_path trajs/datas/KnowAgentHotpotQA_llama-2-13b_D0.jsonl \
    --output_path train/datas

python train/ALFWorld_reformat.py \
    --input_path trajs/datas/KnowAgentALFWorld_llama-2-13b_D0.jsonl \
    --output_path train/datas

