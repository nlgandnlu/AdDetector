import json
import random
import copy
import argparse
import numpy as np
import re
import os
parser = argparse.ArgumentParser(description='Parsing the file_path to reformat and to save the data.')
parser.add_argument("--output_path", type=str, help="output data path", default='/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/trajs/')
parser.add_argument("--input_path", type=str, help="input data path", default='/home/baihaitao/transformers/examples/pytorch/sequence-labeling/ZHIHU-16K/ZHIHU_train/')
args = parser.parse_args()
output_path = args.output_path
if output_path[-1]!='/':
    output_path+='/'
save_path = f"{output_path}ZHIHU_data_train"+".json" 
input_path = args.input_path
data_actionpath = []

tem1 = """
你是一个有用的软文广告检测助手，能够帮助识别和标记潜在的软文广告内容。你的任务是分析给定的文本，并根据以下标准判断是否为软文广告：
1. 推销性质：文本中是否存在过度的商品或服务推荐。
2. 夸大宣传：文本是否使用夸张、极端或误导性的语言，试图使产品或服务看起来比实际更具吸引力或效果。
3. 隐性广告：文本是否隐藏了广告的性质，似乎是个人或中立的内容，但实际上是为了推广某个品牌、产品或服务。
请根据这些标准仔细分析文本，提供一个判断结果，明确指出是否为软文广告。
这是一些例子：
文本: 先上硬菜，传送门：黄大礼：喜欢玩游戏买什么手机？
适合王者、吃鸡的游戏手机推荐（2020年9月）游戏手机几个必备的特点，来判断它是不是适合玩游戏：1、处理器（CPU）手机芯片是一款手机的大脑，是最影响游戏性能的因素。
从鲁大师Q2季度的手机芯片排行榜来看，高通骁龙865在CPU和GPU方面的跑分领先第二名一大截；而天玑1000+和华为的旗舰芯片麒麟9905G相差不大。
为了追求极致的游戏性能，我们选购手机时看这3个CPU型号就够了。
（高通骁龙865plus于7月8号发布，未在图上体现）2、散热手机在玩游戏时，散热好坏不仅影响游戏的流畅度，而且影响玩家的体验和心情。
专业的游戏手机通常内置一个小风扇转动，以带走热量，而且有液态水冷散热，保证热量被持续带走。
3、屏幕刷新率从原理上来看，在手机上看视频、玩游戏实际上就是一个个图片在翻转，屏幕刷新率越高，我们就感觉它越流畅。
现在的智能手机屏幕刷新率通常是60hz，好点的是90hz这样，有些专业的电竞手机达到了144hz的高刷。
4、内存内存分为运行内存（RAM）和手机内存（ROM），游戏手机主要优化的是运行内存，增加游戏时的流畅度。
主流的智能手机RAM通常是8G或者12G，游戏手机有些已经达到16G。
5、手机屏幕电竞手机的手机屏幕在刷新率、屏幕分辨率、屏幕大小方面的参数通常是最佳的，以带来最好的游戏体验。
另外，因为游戏玩家对手机的使用时间较长，游戏手机的屏幕通常还使用了护眼、防蓝光等技术。
6、待机时间游戏手机的待机时间必须要长，现在有些手机配置5000mAh、6000mAh大电池，同时支持快充，不耽误游戏时间。
7、音效游戏玩家对音效的要求很高，尤其是吃鸡这类即时战斗型游戏。
通常搭配双扬声器的游戏手机，是比较受欢迎的。
一、专业的游戏手机推荐：二、品牌的电竞级手机推荐（1）高通骁龙865（2）天玑1000+
这里只做部分节选，关于每个手机的介绍在文章里，欢迎参考。
是否为软文广告（yes or no）: yes

现在轮到你了：
文本: """

tem2= """\n是否为软文广告（yes or no）: """
len_list=[]
txt_files = [f for f in os.listdir(input_path+'text/') if f.endswith('.txt')]
for t_f in txt_files:
    with open(input_path+'text/'+t_f, 'r', encoding='utf-8') as file:
        text = file.read()
    if 'no' in t_f:
        label = 'no'
    else:
        label = 'yes'
    d_actionpath = {"input": tem1 + text + tem2, "output": ""}
    d_actionpath["output"] = label+'\n'
    len_list.append(len(d_actionpath['input']))
    data_actionpath.append(copy.copy(d_actionpath))



mean_value = np.mean(len_list)
max_value = np.max(len_list)
percentile_80 = np.percentile(len_list, 90)
data_actionpath_claim_filter=[]
print(mean_value, max_value, percentile_80)
for l, d in zip(len_list, data_actionpath):
    if l<percentile_80:
        data_actionpath_claim_filter.append(d)

print("The length of the json",len(data_actionpath_claim_filter))



with open(save_path, "w", encoding='utf-8') as f_actionpath:
    json.dump(data_actionpath_claim_filter, f_actionpath, indent=4, ensure_ascii=False)