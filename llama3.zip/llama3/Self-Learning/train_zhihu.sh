echo "####################"

deepspeed --include localhost:3 --master_port 16663 train/train_lora.py \
    --model_name_or_path  models/llama/ \
    --lora_r 8 \
    --lora_alpha 16 \
    --lora_dropout 0.05 \
    --data_path trajs/ZHIHU_data_train.json \
    --output_dir models/llama/zhihu \
    --num_train_epochs 1 \
    --per_device_train_batch_size 1 \
    --per_device_eval_batch_size 1 \
    --gradient_accumulation_steps 2 \
    --evaluation_strategy "no" \
    --save_strategy "steps" \
    --save_steps 10000 \
    --save_total_limit 1 \
    --learning_rate 1e-4 \
    --weight_decay 0. \
    --warmup_ratio 0.03 \
    --lr_scheduler_type "cosine" \
    --logging_steps 1 \
    --fp16 True \
    --model_max_length 8192 \
    --gradient_checkpointing True \
    --q_lora False \
    --resume_from_checkpoint False
