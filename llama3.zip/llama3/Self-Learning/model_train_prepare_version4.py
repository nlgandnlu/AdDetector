import os
import argparse 
import json
import numpy as np
import pandas as pd
import concurrent
import joblib
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline, StoppingCriteriaList, StoppingCriteria
from peft import PeftModel
import warnings
from tqdm import tqdm
warnings.filterwarnings('ignore')


parser = argparse.ArgumentParser(description='Parsing the input of agents, llms and llm context length.')
parser.add_argument("--llm_name", type=str, help="Name of the llm", default="llama-3-8B")
parser.add_argument("--max_context_len", type=int, help="Maximum context length", default=8196)
parser.add_argument("--dataset", type=str, required=True, help="dataset name",default="PolitiFact")
parser.add_argument("--output_path", type=str, required=True, help="output path")
parser.add_argument("--version", type=str, required=True, help="model version")
parser.add_argument("--peft_mode", type=str, required=True, help="ori/sup", default='ori')
parser.add_argument("--epoch", type=int, help="epoch num", default=5)


args = parser.parse_args()

agent_name = "PlanKG_" + args.dataset
llm_name = args.llm_name
max_context_len = args.max_context_len
epoch = args.epoch
peft_mode=args.peft_mode
version = args.version
output_path=args.output_path
llama_model_Path='/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/models/llama/'
article_model_Path='/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/models/article_llm'
claim_model_Path='/home/baihaitao/fake_news/KnowAgent-main/Self-Learning/models/claim_llm/'

if output_path[-1]!='/':
    output_path+='/'

class KeyWordOne_StoppingCriteria(StoppingCriteria):
    def __init__(self,keyword,tokenizer,device):
        self.keyword = keyword
        self.keyword_tokens = [tokenizer.encode(x,add_special_tokens = False,return_tensors = 'pt').reshape(-1).to(device) for x in keyword]
        self.tokenizer = tokenizer
    def __call__(self,input_ids,scores,**kwards):
        flag = False
        for end_tokens, end in zip(self.keyword_tokens, self.keyword):
            now_str = self.tokenizer.batch_decode(input_ids[0][len(input_ids[0]) - len(end_tokens):], skip_special_tokens=True)[0]
            if len(input_ids[0]) < len(end_tokens):
                continue
            if end in now_str:
                flag = True
                break
            else:
                continue
        return flag
    
def process_agent_run_step(agent):
    agent.run()

def get_tokenizer(path):

    padding_side = "left"
    tokenizer = AutoTokenizer.from_pretrained(path, padding_side=padding_side)
    if tokenizer.pad_token is None or tokenizer.pad_token_id is None:
        print("Missing padding token, setting padding token to eos_token")
        tokenizer.pad_token = tokenizer.eos_token
        tokenizer.pad_token_id = tokenizer.eos_token_id

    return tokenizer

def get_all_tokenizer():
    # 如果模型保存路径设置为相同，意味着不存在不同的模型，可以在同一个gpu上测试，在平时测试的时候就加载同样的模型即可
    if llama_model_Path == article_model_Path:
        tokenizer = get_tokenizer(llama_model_Path)
        return tokenizer, tokenizer, tokenizer
    else:
        return get_tokenizer(llama_model_Path), get_tokenizer(article_model_Path), get_tokenizer(claim_model_Path)

def get_model(path):

    model_torch_dtype = torch.float16 
    model = AutoModelForCausalLM.from_pretrained(path, torch_dtype=model_torch_dtype)
    return model

def get_all_model():

    # 如果模型保存路径设置为相同，意味着不存在不同的模型，可以在同一个gpu上测试，在平时测试的时候就加载同样的模型即可,这里的写法仍然是之前的device控制的写法，应该修改，以后就是多轮训练了
    ori_model = get_model(llama_model_Path)
    article_merge_model = ori_model
    claim_merge_model = ori_model
    if peft_mode=='sup':
        for e in range(epoch+1):
            print('联合加载epoch',e)
            peft_path = 'M'+str(e)+'_article'
            article_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_path)
            article_merge_model = article_p_model.merge_and_unload()
            peft_path = 'M'+str(e)+'_claim'
            claim_p_model = PeftModel.from_pretrained(claim_merge_model, model_id=claim_model_Path+'/'+peft_path)
            claim_merge_model = claim_p_model.merge_and_unload()
            if e<epoch:
                peft_sup_path = 'M'+str(e)+'_sup'
                sup_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_sup_path)
                article_merge_model = sup_p_model.merge_and_unload()
    elif peft_mode=='article' or peft_mode=='claim':
        # 加载到epoch_sup即可,由于article和claim模型不一样所以二者加载逻辑是一致的，准备训这两个没有区别，都是准备好sup和sup之前的模型即可
        for e in range(epoch):
            print('联合加载epoch',e)
            peft_path = 'M'+str(e)+'_article'
            article_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_path)
            article_merge_model = article_p_model.merge_and_unload()
            peft_path = 'M'+str(e)+'_claim'
            claim_p_model = PeftModel.from_pretrained(claim_merge_model, model_id=claim_model_Path+'/'+peft_path)
            claim_merge_model = claim_p_model.merge_and_unload()
            peft_sup_path = 'M'+str(e)+'_sup'
            sup_p_model = PeftModel.from_pretrained(article_merge_model, model_id=article_model_Path+'/'+peft_sup_path)
            article_merge_model = sup_p_model.merge_and_unload()
    
    return article_merge_model, claim_merge_model

def get_llm(model, tokenizer, mode, name):
    # 根据模式设置不同的温度，训练模式应更多样化，验证和测试应保证结果可复现性
    if mode == 'train':
        tem = 1.0
    else:
        tem=0

    if name == 'article_llm':
        # article_llm， 使用列表对象作为格式化输出，方便总体协调处理
        stopcrieria = KeyWordOne_StoppingCriteria(['\n',']'],tokenizer=tokenizer,device=article_device)
        terminators = [
                        tokenizer.eos_token_id,
                        tokenizer.convert_tokens_to_ids("<|eot_id|>")
                        ]
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            device=article_device,
            #max_length=8192,
            temperature=tem,
            max_new_tokens=512,
            do_sample=False,
            stopping_criteria=StoppingCriteriaList([stopcrieria]),
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=terminators,
        )
        llm = get_llm_backend(pipe=pipe).run
        return llm
    elif name == 'claim_llm':
        # 使用claim验证model，三种情况可以停止：thought结束时的换行，每个行动步骤以及最终给出分析报告后的].
        stopcrieria = KeyWordOne_StoppingCriteria(['\n',']'],tokenizer=tokenizer,device=claim_device)
        terminators = [
                        tokenizer.eos_token_id,
                        tokenizer.convert_tokens_to_ids("<|eot_id|>")
                        ]
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            device=claim_device,
            #max_length=8192,
            temperature=tem,
            max_new_tokens=256,
            do_sample=False,
            stopping_criteria=StoppingCriteriaList([stopcrieria]),
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=terminators,
        )
        llm = get_llm_backend(pipe=pipe).run
        return llm
    else:
        # 使用其他model, 一般就是换行停止。
        stopcrieria = KeyWordOne_StoppingCriteria(['\n'],tokenizer=tokenizer,device=llama_device)
        terminators = [
                        tokenizer.eos_token_id,
                        tokenizer.convert_tokens_to_ids("<|eot_id|>")
                        ]
        pipe = pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            device=llama_device,
            #max_length=8192,
            temperature=0,
            max_new_tokens=256,
            do_sample=False,
            stopping_criteria=StoppingCriteriaList([stopcrieria]),
            pad_token_id=tokenizer.eos_token_id,
            eos_token_id=terminators,
        )
        llm = get_llm_backend(pipe=pipe).run
        return llm
    
def main():
    article_model, claim_model = get_all_model()
    article_model.save_pretrained(article_model_Path)
    claim_model.save_pretrained(claim_model_Path)

if __name__ == '__main__':
    main()